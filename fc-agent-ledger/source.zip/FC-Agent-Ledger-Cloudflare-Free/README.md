# FC Agent Ledger — Cloudflare **permanent Free** edition

**Current status: local source and SQLite integration tests ready; NOT deployed or connected to user's Cloudflare account.** The previous Render project was not created. This code is **not** a publicly running site.

## Why this edition

- **Cloudflare Workers Free** = HTTPS web app + backend with permanent free allowance (not a 30-day trial).
- **Cloudflare D1 Free** = dedicated SQLite-like cloud database for this product (not shared with the user's other production app databases).
- No card, paid subscription, external Postgres service or Render required for this *code path*.
- User must own and authorize the Cloudflare account before provisioning a real D1 database and publishing the Worker.

## Current Cloudflare Free quotas, verified November 2026

- Worker: 100,000 requests/day; **10 ms CPU/request**. Requests exceeding limits may fail rather than incur automatic charge on Free.
- D1: 5 million rows read/day, 100,000 rows written/day; maximum **500 MB per D1 database**, 5 GB total storage/account, 10 free databases, and **50 D1 queries/Worker invocation**.
- D1 Time Travel: rolling 7 days on Free. Export backups more frequently and retain offsite; no indefinite backups.
- These are permanent **free allowances, not unlimited service**; there is no commercial platform with guaranteed unlimited computing/storage for $0.
- Password hashing is PBKDF2 150k SHA-256 via WebCrypto. **Performance under the 10 ms Free CPU limit must be measured on a deployed Worker**. The Node tests do not certify this.

Official documentation:
- https://developers.cloudflare.com/workers/platform/limits/
- https://developers.cloudflare.com/d1/platform/pricing/
- https://developers.cloudflare.com/d1/platform/limits/
- https://developers.cloudflare.com/d1/reference/time-travel/

## System roles

| User | Scope |
|---|---|
| `SUPER_ADMIN` | Manages only organization names, subscription plans, active/suspended status, expiry and admin account creation. Does **not** browse an organization's tickets. |
| `ADMIN` | Only its own `organization_id`: creates fixtures and odds, manages its agents and their tickets, confirms 90-minute results and reviews reports. |
| `AGENT` | Only own account and their admin organization's listed fixtures; creates own BODY and MOUNG tickets, reads own history and reports. |

No public signup; admin accounts sold by Super Admin; agent accounts created by each Admin. Every SQL query on tenant-owned data checks tenant ID derived from the authenticated **server-side session**, never an incoming `organizationId`.

## Football settlement rules

- Quoted handicap BODY: `1+35`, `2+35`, `1-30`, `L-50` exactly as confirmed by user.
- Totals: `3+35` for goals OVER/UNDER, combined scores from the two teams.
- Normal time **90 minutes plus stoppage time**, exclude extra-time and penalties.
- Canceled match in a BODY ticket refunds original stake; void MOUNG leg multiplies by 1.00; MOUNG ticket remains active on other legs; all canceled legs refund; a 100% losing leg returns 0.
- BODY has 1 selection and 1 stake; MOUNG has 4–12 distinct matches and only **1 stake for the whole ticket**.
- Original odds are snapshotted into accepted ticket rows, later admin quote changes create new revisions and do not alter tickets.
- Currency integer MMK, rounding half up on **final ticket payout**. Rounding convention still needs owner sign-off.
- Unsupported quote patterns are deliberately rejected; this is **not** a general arbitrary-odds calculator yet.

## Test the code locally

Requires Node.js 22+, so Node's built-in experimental SQLite is available for test simulation.

```bash
node --test tests/*.test.mjs
node --check src/worker.mjs
```

SQLite tests currently cover 11 cases: calculation, Super Admin initial setup, auth, cross-tenant denial, agent restrictions, settlement, preventing score revisions, and bulk processing 120 tickets. **Cloudflare production integration/security/CPU tests are still outstanding.**

## Cloudflare deployment — completely Free path

> These steps require the Cloudflare account owner's own login/authorization. Never paste secret token or password into ChatGPT, the GitHub repository, or a public chat.

1. Download/extract this ZIP to a computer with Node.js 20.11+; open a terminal in `FC-Agent-Ledger-Cloudflare-Free`.
2. Open https://dash.cloudflare.com and ensure **Workers Free** is selected — do **not** enable a paid plan.
3. Run `npm install` and `npx wrangler login`; approve Cloudflare access in the user's own browser.
4. Run `npx wrangler d1 create fc-agent-ledger-db`. Copy the new `database_id` into the `database_id` value in `wrangler.jsonc` (replace only the `REPLACE_WITH_YOUR_D1_DATABASE_ID` placeholder).
5. Run `npm run migrate:remote` to create schema, indexes, and concurrency constraints.
6. Generate a cryptographically random 32+ character setup secret **privately**. Example terminal command (run it yourself, don't paste output here): `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`.
7. Run `npx wrangler secret put SETUP_TOKEN` and type the privately generated secret. This secret is temporary, only for first owner creation.
8. Run `npm run deploy`. Wrangler prints the **actual** deployed HTTPS `*.workers.dev` URL — verify `/health` returns `{ "ok": true }`.
9. Open the URL, choose first-time Super Admin setup, enter the temporary setup token + your email and strong password. Confirm owner login, then **immediately remove** `SETUP_TOKEN` via `npx wrangler secret delete SETUP_TOKEN`.
10. Create two throwaway Admin accounts and Agent accounts for each, create fixtures in each, and confirm agents in one Admin cannot fetch or edit the other's tickets, fixtures or reports. Check Cloudflare dashboard's Worker errors and CPU-time metrics. **Do not accept real customer data until checks pass.**

If `wrangler d1 create` says the database already exists, do **not** overwrite existing apps' databases. Use its ID only if it is clearly this app's dedicated `fc-agent-ledger-db` database.

## What still requires production work

- Confirm Cloudflare Workers Free's 10 ms CPU is sufficient for PBKDF2 hashing and bulk settlement; cannot be proven with local Node tests alone.
- Commercial, legal and security validation appropriate to handling real betting records; password reset and admin MFA; secure password handoff; account recovery; backups/restores; automated monitoring.
- Ticket cancellation/correction/reconciliation and settlement retry model for extremely high-volume events; reconcile balance/cash movements.
- Cloudflare Free has hard quota caps. More Admin customers and tickets may exceed them; do not promise unlimited business capacity.

## Files

- `src/worker.mjs`: Workers/D1 backend and role-secured API.
- `src/settlement.mjs`: deterministic accounting logic.
- `migrations/0001_initial.sql`: Cloudflare D1 migration; creates app-only schema.
- `public/*`: Burmese mobile-first Admin/Super Admin/Agent dashboard interface.
- `wrangler.jsonc`: Worker + D1 config, **requires database ID**.
- `tests/*`: Node SQL integration and business-rule checks.
