import {parseQuote, settleTicket} from './settlement.mjs';

// FC Agent Ledger — Cloudflare Workers + D1, account-scoped application.
// All API writes are authenticated. D1 is never exposed directly to the browser.
const headers = {'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'x-content-type-options':'nosniff', 'referrer-policy':'same-origin'};
class HttpError extends Error {constructor(status,message){super(message);this.status=status}}
const fail=(n,s)=>{throw new HttpError(n,s)};
const json=(v,status=200,extra={})=>new Response(JSON.stringify(v),{status,headers:{...headers,...extra}});
const id=()=>crypto.randomUUID();
const now=()=>new Date().toISOString();
const dateAfterDays=n=>new Date(Date.now()+n*86400000).toISOString();
const validEmail=v=>typeof v==='string'&&v.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const validMoney=n=>Number.isSafeInteger(n)&&n>0&&n<=1000000000;
const validGoals=n=>Number.isInteger(n)&&n>=0&&n<=99;
const cleanString=(v,max=100)=>String(v??'').trim().slice(0,max);
const normalizeEmail=v=>v.trim().toLowerCase();
const s=(env,sql,...params)=>env.DB.prepare(sql).bind(...params);
const one=(env,sql,...params)=>s(env,sql,...params).first();
const many=async(env,sql,...params)=>(await s(env,sql,...params).all()).results||[];
const run=(env,sql,...params)=>s(env,sql,...params).run();
const audit=(env,u,action,entity,entityId,detail={})=>s(env,'INSERT INTO audit_logs (id,organization_id,actor_id,action,entity,entity_id,details) VALUES(?,?,?,?,?,?,?)',id(),u?.organization_id??null,u?.id??null,action,entity,entityId,JSON.stringify(detail));
const hex=bytes=>Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');
const bytesOf=hexString=>Uint8Array.from(hexString.match(/.{2}/g)||[],h=>parseInt(h,16));
const randomHex=n=>{const a=new Uint8Array(n);crypto.getRandomValues(a);return hex(a)};
const hashSha=async v=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v)));
// Password-hashing via WebCrypto PBKDF2; on production test CPU-budget of chosen Workers Free region.
const ITERATIONS=150000;
async function derivePassword(password,salt,iterations){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytesOf(salt),iterations,hash:'SHA-256'},key,256));
}
async function passwordHash(password){if(typeof password!=='string'||password.length<12||password.length>160)fail(400,'Password အနည်းဆုံး ၁၂ လုံးဖြည့်ပါ');const salt=randomHex(16);return `pbkdf2:${ITERATIONS}:${salt}:${await derivePassword(password,salt,ITERATIONS)}`;}
async function verifyPassword(password,stored){
 if(typeof password!=='string'||typeof stored!=='string'||!stored.startsWith('pbkdf2:'))return false;
 const [_,n,salt,expected]=stored.split(':');const count=Number(n);
 if(!Number.isInteger(count)||count<100000||count>2000000||!salt||!expected)return false;
 const actual=await derivePassword(password,salt,count);const a=bytesOf(actual),b=bytesOf(expected);
 if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];return diff===0;
}
async function body(request){
 if(!request.headers.get('content-type')?.startsWith('application/json'))fail(415,'JSON required');
 const len=Number(request.headers.get('content-length')||0);if(len>100000)fail(413,'Payload too large');
 const txt=await request.text();if(txt.length>100000)fail(413,'Payload too large');
 try{const x=JSON.parse(txt);if(!x||Array.isArray(x)||typeof x!=='object')fail(400,'Invalid payload');return x}
 catch(e){if(e instanceof HttpError)throw e;fail(400,'JSON ပုံစံမှားနေပါတယ်')}
}
function verifyOrigin(request){const origin=request.headers.get('origin');if(origin){let a;try{a=new URL(origin)}catch{fail(403,'Invalid Origin')}if(a.origin!==new URL(request.url).origin)fail(403,'Cross-site request blocked')}}
function selectedCookie(req){return /(?:^|;\s*)fc_sid=([^;]+)/.exec(req.headers.get('cookie')||'')?.[1]||''}
async function auth(env,request){const token=selectedCookie(request);if(!token)return null;
 return one(env,`SELECT u.id,u.organization_id,u.display_name,u.email,u.role FROM sessions sess
 JOIN users u ON u.id=sess.user_id LEFT JOIN organizations o ON o.id=u.organization_id
 WHERE sess.token_hash=? AND sess.expires_at>? AND u.active=1
 AND (u.role='SUPER_ADMIN' OR (o.active=1 AND (o.expires_at IS NULL OR o.expires_at>?)))`,await hashSha(token),now(),now());
}
function role(u,...allowed){if(!u)fail(401,'အကောင့် Login လိုအပ်ပါတယ်');if(!allowed.includes(u.role))fail(403,'ဒီလုပ်ဆောင်ချက်ကို ခွင့်မပြုပါ')}
function parseCode(code,market,giver){try{return parseQuote(code,market,giver)}catch(e){fail(400,e.message)}}
function kickoffIso(x){if(typeof x!=='string')fail(400,'ပွဲချိန် မမှန်ပါ');const d=/^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(x)?new Date(x+':00+06:30'):new Date(x);if(!Number.isFinite(+d)||+d<=Date.now()+60000)fail(400,'အနာဂတ်ပွဲချိန် ထည့်ပါ');return d.toISOString()}
async function login(env,req){const d=await body(req);if(!validEmail(d.email)||typeof d.password!=='string')fail(400,'Email နှင့် Password ဖြည့်ပါ');
 const u=await one(env,`SELECT u.*,o.active AS org_active,o.expires_at AS org_expires FROM users u LEFT JOIN organizations o ON o.id=u.organization_id WHERE u.email=?`,normalizeEmail(d.email));
 if(u?.locked_until&&u.locked_until>now())fail(429,'Account temporarily locked');
 const enabled=u&&u.active&&(u.role==='SUPER_ADMIN'||(u.org_active&&(!u.org_expires||u.org_expires>now())));
 const okay=enabled&&await verifyPassword(d.password,u.password_hash);
 if(!okay){if(u){const fails=u.failed_logins+1;await run(env,'UPDATE users SET failed_logins=?,locked_until=? WHERE id=?',fails,fails>=7?new Date(Date.now()+900000).toISOString():u.locked_until,u.id)}fail(401,'Email သို့မဟုတ် Password မှားနေပါတယ်')}
 const token=randomHex(32);await env.DB.batch([
  s(env,'UPDATE users SET failed_logins=0,locked_until=NULL WHERE id=?',u.id),
  s(env,'INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)',await hashSha(token),u.id,dateAfterDays(7))
 ]);
 return json({ok:true,user:{id:u.id,name:u.display_name,role:u.role,organizationId:u.organization_id}},200,{'set-cookie':`fc_sid=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=604800`});
}
async function bootstrapStatus(env){return json({needsSetup:!(await one(env,"SELECT 1 FROM users WHERE role='SUPER_ADMIN' LIMIT 1")),enabled:typeof env.SETUP_TOKEN==='string'&&env.SETUP_TOKEN.length>=32})}
async function bootstrap(env,req){const d=await body(req);if(typeof env.SETUP_TOKEN!=='string'||env.SETUP_TOKEN.length<32||d.setupToken!==env.SETUP_TOKEN)fail(403,'Setup disabled or token invalid');
 if(!validEmail(d.email)||!cleanString(d.displayName))fail(400,'Owner email/name required');const hashed=await passwordHash(d.password),uid=id();
 // Partial unique index guarantees at most one platform owner even in concurrent setup calls.
 const r=await run(env,`INSERT INTO users(id,organization_id,email,display_name,password_hash,role)
 SELECT ?,NULL,?,?,?,'SUPER_ADMIN' WHERE NOT EXISTS(SELECT 1 FROM users WHERE role='SUPER_ADMIN')`,uid,normalizeEmail(d.email),cleanString(d.displayName),hashed);
 if(!r.meta.changes)fail(409,'Super Admin already exists');return json({ok:true,message:'Super Admin created — remove SETUP_TOKEN from Worker secrets immediately'},201);
}
async function passwordChange(env,u,req){const d=await body(req);const row=await one(env,'SELECT password_hash FROM users WHERE id=?',u.id);if(!row||!await verifyPassword(d.currentPassword,row.password_hash))fail(403,'Current Password မှားနေပါတယ်');
 const hashed=await passwordHash(d.newPassword);const sid=await hashSha(selectedCookie(req));
 await env.DB.batch([s(env,'UPDATE users SET password_hash=? WHERE id=?',hashed,u.id),s(env,'DELETE FROM sessions WHERE user_id=? AND token_hash<>?',u.id,sid),audit(env,u,'CHANGE_PASSWORD','user',u.id)]);
 return json({ok:true});
}
async function dashboard(env,u){if(u.role==='SUPER_ADMIN')return json(await one(env,`SELECT (SELECT count(*) FROM organizations) AS organizations,
 (SELECT count(*) FROM organizations WHERE active=1) AS active_organizations,
 (SELECT count(*) FROM users WHERE role='ADMIN' AND active=1) AS admins`));
 const b=u.role==='AGENT'?await one(env,`SELECT count(*) tickets,COALESCE(sum(CASE WHEN status='PENDING' THEN 1 ELSE 0 END),0) pending,COALESCE(sum(net_kyat),0) player_net_kyat,COALESCE(sum(stake_kyat),0) stakes_kyat FROM tickets WHERE organization_id=? AND agent_id=?`,u.organization_id,u.id)
 :await one(env,`SELECT count(*) tickets,COALESCE(sum(CASE WHEN status='PENDING' THEN 1 ELSE 0 END),0) pending,COALESCE(sum(net_kyat),0) player_net_kyat,COALESCE(sum(stake_kyat),0) stakes_kyat FROM tickets WHERE organization_id=?`,u.organization_id);
 return json(b);
}
async function tenants(env){return json(await many(env,`SELECT o.*,sum(CASE WHEN u.role='ADMIN' THEN 1 ELSE 0 END) admins,sum(CASE WHEN u.role='AGENT' THEN 1 ELSE 0 END) agents FROM organizations o LEFT JOIN users u ON u.organization_id=o.id GROUP BY o.id ORDER BY o.created_at DESC`))}
async function createTenant(env,u,req){const d=await body(req);if(!cleanString(d.name)||!cleanString(d.displayName)||!validEmail(d.email))fail(400,'လုပ်ငန်းအမည်၊ Admin Email နှင့် နာမည်ဖြည့်ပါ');
 const p=await passwordHash(d.password),days=Number(d.planDays||30);if(!Number.isInteger(days)||days<1||days>3660)fail(400,'သက်တမ်းရက် မမှန်ပါ');const oid=id(),uid=id();
 await env.DB.batch([
  s(env,'INSERT INTO organizations(id,name,plan_name,expires_at) VALUES(?,?,?,?)',oid,cleanString(d.name,150),cleanString(d.planName||'STANDARD',80),dateAfterDays(days)),
  s(env,"INSERT INTO users(id,organization_id,email,display_name,password_hash,role) VALUES(?,?,?,?,?,'ADMIN')",uid,oid,normalizeEmail(d.email),cleanString(d.displayName),p),
  audit(env,u,'CREATE_TENANT','organization',oid,{adminId:uid})
 ]);return json({id:oid,adminId:uid},201);
}
async function tenantActive(env,u,req,tenantId){const d=await body(req);if(typeof d.active!=='boolean')fail(400,'active required');const r=await env.DB.batch([
 s(env,'UPDATE organizations SET active=? WHERE id=?',d.active?1:0,tenantId),audit(env,u,'SET_TENANT_ACTIVE','organization',tenantId,{active:d.active})
 ]);if(!r[0].meta.changes)fail(404,'Account not found');return json({id:tenantId,active:d.active})}
async function tenantExtend(env,u,req,tenantId){const d=await body(req),days=Number(d.addDays);if(!Number.isInteger(days)||days<1||days>3660)fail(400,'ရက် ၁ မှ ၃၆၆၀ ထိ');
 const x=await one(env,'SELECT expires_at FROM organizations WHERE id=?',tenantId);if(!x)fail(404,'Account not found');const next=new Date(Math.max(Date.now(),x.expires_at?Date.parse(x.expires_at):0)+days*86400000).toISOString();
 await env.DB.batch([s(env,'UPDATE organizations SET expires_at=?,active=1 WHERE id=?',next,tenantId),audit(env,u,'EXTEND_SUBSCRIPTION','organization',tenantId,{days})]);return json({id:tenantId,expires_at:next,active:true})
}
async function agents(env,u){return json(await many(env,"SELECT id,email,display_name,active,created_at FROM users WHERE organization_id=? AND role='AGENT' ORDER BY created_at DESC",u.organization_id))}
async function agentCreate(env,u,req){const d=await body(req);if(!cleanString(d.displayName)||!validEmail(d.email))fail(400,'Agent name/email required');const p=await passwordHash(d.password),uid=id();
 await env.DB.batch([s(env,"INSERT INTO users(id,organization_id,email,display_name,password_hash,role) VALUES(?,?,?,?,?,'AGENT')",uid,u.organization_id,normalizeEmail(d.email),cleanString(d.displayName),p),audit(env,u,'CREATE_AGENT','user',uid)]);return json({id:uid},201)}
async function agentActive(env,u,req,agentId){const d=await body(req);if(typeof d.active!=='boolean')fail(400,'active boolean required');const r=await env.DB.batch([s(env,"UPDATE users SET active=? WHERE id=? AND organization_id=? AND role='AGENT'",d.active?1:0,agentId,u.organization_id),audit(env,u,'SET_AGENT_ACTIVE','user',agentId,{active:d.active})]);if(!r[0].meta.changes)fail(404,'Agent not found');return json({id:agentId,active:d.active})}
async function matches(env,u){return json(await many(env,`SELECT m.*,qb.quote_code body_code,qb.giver_side,qt.quote_code total_code FROM matches m
 LEFT JOIN odds_quotes qb ON qb.match_id=m.id AND qb.market='BODY' AND qb.active=1
 LEFT JOIN odds_quotes qt ON qt.match_id=m.id AND qt.market='TOTAL' AND qt.active=1
 WHERE m.organization_id=? ORDER BY m.kickoff_at DESC LIMIT 300`,u.organization_id))}
async function createMatch(env,u,req){const d=await body(req),home=cleanString(d.home),away=cleanString(d.away);if(!home||!away||home===away)fail(400,'အသင်းနှစ်သင်း ဖြည့်ပါ');
 const time=kickoffIso(d.kickoff);parseCode(d.bodyCode,'BODY',d.giverSide);parseCode(d.totalCode,'TOTAL');const mid=id();
 await env.DB.batch([
  s(env,'INSERT INTO matches(id,organization_id,league,home_team,away_team,kickoff_at,created_by) VALUES(?,?,?,?,?,?,?)',mid,u.organization_id,cleanString(d.league,120),home,away,time,u.id),
  s(env,"INSERT INTO odds_quotes(id,organization_id,match_id,market,quote_code,giver_side,revision,created_by) VALUES(?,?,?,'BODY',?,?,1,?)",id(),u.organization_id,mid,d.bodyCode,d.giverSide,u.id),
  s(env,"INSERT INTO odds_quotes(id,organization_id,match_id,market,quote_code,revision,created_by) VALUES(?,?,?,'TOTAL',?,1,?)",id(),u.organization_id,mid,d.totalCode,u.id),
  audit(env,u,'CREATE_MATCH','match',mid,{home,away})
 ]);return json({id:mid},201)}
async function changeQuote(env,u,req,mid){const d=await body(req),market=d.market;if(!['BODY','TOTAL'].includes(market))fail(400,'Market invalid');const code=parseCode(d.code,market,d.giverSide).code;
 const match=await one(env,'SELECT id,status,kickoff_at FROM matches WHERE id=? AND organization_id=?',mid,u.organization_id);if(!match)fail(404,'Match not found');if(match.status!=='SCHEDULED'||match.kickoff_at<=now())fail(409,'ပွဲစပြီးနောက် ကြေးမပြင်နိုင်');
 const rev=await one(env,'SELECT COALESCE(MAX(revision),0)+1 revision FROM odds_quotes WHERE organization_id=? AND match_id=? AND market=?',u.organization_id,mid,market);
 await env.DB.batch([
  s(env,'UPDATE odds_quotes SET active=0 WHERE organization_id=? AND match_id=? AND market=? AND active=1',u.organization_id,mid,market),
  s(env,'INSERT INTO odds_quotes(id,organization_id,match_id,market,quote_code,giver_side,revision,created_by) VALUES(?,?,?,?,?,?,?,?)',id(),u.organization_id,mid,market,code,market==='BODY'?d.giverSide:null,rev.revision,u.id),
  audit(env,u,'UPDATE_QUOTE','match',mid,{market,revision:rev.revision})
 ]);return json({revision:rev.revision},201)
}
async function ticketsCreate(env,u,req){const d=await body(req);if(!['BODY','MOUNG'].includes(d.type)||!validMoney(d.stakeKyat)||!Array.isArray(d.selections))fail(400,'Ticket data invalid');
 if(d.type==='BODY'&&d.selections.length!==1)fail(400,'ဘော်ဒီ တစ်ပွဲသာ');if(d.type==='MOUNG'&&(d.selections.length<4||d.selections.length>12))fail(400,'မောင်း ၄–၁၂ ပွဲ');
 if(new Set(d.selections.map(x=>x?.matchId)).size!==d.selections.length)fail(400,'ပွဲတူ မထပ်ရပါ');if(typeof d.idempotencyKey!=='string'||d.idempotencyKey.length<10||d.idempotencyKey.length>100)fail(400,'Idempotency key required');
 const existing=await one(env,'SELECT id,ticket_number FROM tickets WHERE organization_id=? AND agent_id=? AND idempotency_key=?',u.organization_id,u.id,d.idempotencyKey);if(existing)return json(existing,200);
 const selections=[];
 for(const item of d.selections){if(!item||!['BODY','TOTAL'].includes(item.market))fail(400,'Market invalid');if(!((item.market==='BODY'&&['HOME','AWAY'].includes(item.pick))||(item.market==='TOTAL'&&['OVER','UNDER'].includes(item.pick))))fail(400,'Pick invalid');
 const x=await one(env,`SELECT m.status,m.kickoff_at,m.id match_id,q.id quote_id,q.quote_code,q.market,q.giver_side FROM matches m
 JOIN odds_quotes q ON q.match_id=m.id AND q.organization_id=m.organization_id
 WHERE m.organization_id=? AND m.id=? AND q.market=? AND q.active=1`,u.organization_id,item.matchId,item.market);
 if(!x||x.status!=='SCHEDULED'||x.kickoff_at<=now())fail(409,'ပွဲစပြီး / ပွဲမရှိပါ');selections.push({...x,pick:item.pick,quote:parseCode(x.quote_code,item.market,x.giver_side)})}
 const tid=id(),ticketNum=(d.type==='BODY'?'B':'M')+'-'+tid.slice(0,8).toUpperCase();
 const batch=[s(env,'INSERT INTO tickets(id,organization_id,ticket_number,agent_id,ticket_type,stake_kyat,idempotency_key) VALUES(?,?,?,?,?,?,?)',tid,u.organization_id,ticketNum,u.id,d.type,d.stakeKyat,d.idempotencyKey)];
 selections.forEach((x,i)=>batch.push(s(env,'INSERT INTO ticket_selections(id,organization_id,ticket_id,match_id,quote_id,position,chosen_side,quote_snapshot) VALUES(?,?,?,?,?,?,?,?)',id(),u.organization_id,tid,x.match_id,x.quote_id,i+1,x.pick,JSON.stringify(x.quote))));
 batch.push(audit(env,u,'CREATE_TICKET','ticket',tid,{type:d.type,legs:selections.length,stakeKyat:d.stakeKyat}));
 await env.DB.batch(batch);return json({id:tid,ticket_number:ticketNum},201)
}
async function tickets(env,u,url){const adminAgent=u.role==='AGENT'?u.id:url.searchParams.get('agentId');let list;if(adminAgent){
 list=await many(env,`SELECT t.*,a.display_name agent_name FROM tickets t JOIN users a ON a.id=t.agent_id AND a.organization_id=t.organization_id WHERE t.organization_id=? AND t.agent_id=? ORDER BY t.accepted_at DESC LIMIT 250`,u.organization_id,adminAgent);
 }else{list=await many(env,`SELECT t.*,a.display_name agent_name FROM tickets t JOIN users a ON a.id=t.agent_id AND a.organization_id=t.organization_id WHERE t.organization_id=? ORDER BY t.accepted_at DESC LIMIT 250`,u.organization_id)}
 if(!list.length)return json([]);
 // D1 has no PG ANY(uuid[]) operator. Limit parameter count by page size (<=250).
 const params=adminAgent?[u.organization_id,u.organization_id,adminAgent]:[u.organization_id,u.organization_id];
 const agentClause=adminAgent?' AND t.agent_id=?':'';
 const results=await many(env,`SELECT s.ticket_id,s.position,s.match_id,s.chosen_side,s.quote_snapshot,s.settlement_state,s.factor_bp,
 m.home_team,m.away_team,m.status match_status,m.home_goals_90,m.away_goals_90
 FROM ticket_selections s JOIN matches m ON m.id=s.match_id AND m.organization_id=s.organization_id
 WHERE s.organization_id=? AND s.ticket_id IN (
 SELECT t.id FROM tickets t WHERE t.organization_id=? ${agentClause} ORDER BY t.accepted_at DESC LIMIT 250
 ) ORDER BY s.ticket_id,s.position`,...params);
 const legs=new Map();for(const x of results){x.quote_snapshot=JSON.parse(x.quote_snapshot);const a=legs.get(x.ticket_id)||[];a.push(x);legs.set(x.ticket_id,a)}
 return json(list.map(t=>({...t,selections:legs.get(t.id)||[]})));
}
async function reports(env,u){const condition=u.role==='AGENT'?' AND a.id=?':'';const args=u.role==='AGENT'?[u.organization_id,u.id]:[u.organization_id];
 return json(await many(env,`SELECT a.id,a.display_name,a.email,COUNT(t.id) tickets,
 sum(CASE WHEN t.status='PENDING' THEN 1 ELSE 0 END) pending,
 COALESCE(sum(t.stake_kyat),0) total_stake_kyat,
 COALESCE(sum(t.net_kyat),0) player_net_kyat,
 -COALESCE(sum(t.net_kyat),0) admin_net_kyat
 FROM users a LEFT JOIN tickets t ON t.agent_id=a.id AND t.organization_id=a.organization_id
 WHERE a.organization_id=? AND a.role='AGENT' ${condition} GROUP BY a.id ORDER BY a.display_name`,...args))}
async function settleMatch(env,u,mid,d,commit){const m=await one(env,'SELECT id,status,kickoff_at FROM matches WHERE id=? AND organization_id=?',mid,u.organization_id);
 if(!m)fail(404,'Match not found');if(m.status!=='SCHEDULED')fail(409,'Result already confirmed');
 const state=d.void===true?'VOID':'FINAL';
 // A canceled match can be voided before kickoff. Final score must not be recorded during play.
 if(state==='FINAL'&&Date.parse(m.kickoff_at)+90*60000>Date.now())fail(400,'မိနစ် ၉၀ မပြည့်သေးပါ');
 if(state==='FINAL'&&(!validGoals(d.homeGoals)||!validGoals(d.awayGoals)))fail(400,'မိနစ် ၉၀ ဂိုးရလဒ် မမှန်ပါ');
 const related=await many(env,`SELECT DISTINCT t.id,t.ticket_type,t.stake_kyat,t.agent_id,t.status ticket_status
 FROM tickets t JOIN ticket_selections s ON s.ticket_id=t.id AND s.organization_id=t.organization_id
 WHERE t.organization_id=? AND s.match_id=? ORDER BY t.id`,u.organization_id,mid);
 // One joined read replaces an N+1 query loop, keeping D1 Free within its 50-query/request limit.
 const legRows=related.length?await many(env,`SELECT s.id,s.ticket_id,s.match_id,s.position,s.chosen_side,s.quote_snapshot,
 m.status,m.home_goals_90,m.away_goals_90 FROM ticket_selections s
 JOIN matches m ON m.id=s.match_id AND m.organization_id=s.organization_id
 WHERE s.organization_id=? AND s.ticket_id IN (SELECT DISTINCT ticket_id FROM ticket_selections WHERE organization_id=? AND match_id=?)
 ORDER BY s.ticket_id,s.position`,u.organization_id,u.organization_id,mid):[];
 const grouped=new Map();for(const leg of legRows){const rows=grouped.get(leg.ticket_id)||[];rows.push(leg);grouped.set(leg.ticket_id,rows)}
 const allUpdates=[];
 for(const t of related){const rows=grouped.get(t.id)||[],lookup={},selections=[];
 for(const x of rows){lookup[x.match_id]=x.match_id===mid?{status:state,homeGoals:d.homeGoals,awayGoals:d.awayGoals}:{status:x.status,homeGoals:x.home_goals_90,awayGoals:x.away_goals_90};selections.push({matchId:x.match_id,pick:x.chosen_side,quote:JSON.parse(x.quote_snapshot)})}
 const calc=settleTicket({type:t.ticket_type,stakeKyat:Number(t.stake_kyat),selections},lookup);allUpdates.push({ticket:t,rows,calc})}
 if(!commit)return json({affected:allUpdates.length,updates:allUpdates.map(x=>({ticketId:x.ticket.id,newState:x.calc.state,payout:x.calc.payoutKyat}))});
 const selectionUpdates=[],ticketUpdates=[],ledgerWrites=[];
 for(const x of allUpdates){x.rows.forEach((row,i)=>selectionUpdates.push({id:row.id,state:x.calc.legs[i].state,factor:x.calc.legs[i].factorBasisPoints}));
  if(x.calc.state!=='PENDING'&&x.ticket.ticket_status==='PENDING'){
   ticketUpdates.push({id:x.ticket.id,state:x.calc.state,payout:x.calc.payoutKyat,net:x.calc.netKyat,settledAt:now()});
   ledgerWrites.push({id:id(),agentId:x.ticket.agent_id,ticketId:x.ticket.id,net:x.calc.netKyat});
  }
 }
 const q=[s(env,"UPDATE matches SET status=?,home_goals_90=?,away_goals_90=?,settled_at=? WHERE id=? AND organization_id=? AND status='SCHEDULED'",state,state==='FINAL'?d.homeGoals:null,state==='FINAL'?d.awayGoals:null,now(),mid,u.organization_id)];
 // Group all selection, ticket and ledger writes into 3 statements via SQLite JSON1.
 // This prevents blowing past the 50 D1 queries per invocation on the permanent Free plan.
 if(selectionUpdates.length){const data=JSON.stringify(selectionUpdates);q.push(s(env,`WITH vals AS (
 SELECT json_extract(value,'$.id') AS row_id,json_extract(value,'$.state') AS st,
 json_extract(value,'$.factor') AS factor FROM json_each(?)
 ) UPDATE ticket_selections SET settlement_state=vals.st,factor_bp=vals.factor
 FROM vals WHERE ticket_selections.id=vals.row_id AND ticket_selections.organization_id=?`,data,u.organization_id))}
 if(ticketUpdates.length){const data=JSON.stringify(ticketUpdates);q.push(s(env,`WITH vals AS (
 SELECT json_extract(value,'$.id') row_id,json_extract(value,'$.state') st,
 json_extract(value,'$.payout') payout,json_extract(value,'$.net') net,
 json_extract(value,'$.settledAt') done FROM json_each(?)
 ) UPDATE tickets SET status=vals.st,payout_kyat=vals.payout,net_kyat=vals.net,settled_at=vals.done
 FROM vals WHERE tickets.id=vals.row_id AND tickets.organization_id=? AND tickets.status='PENDING'`,data,u.organization_id));
 const l=JSON.stringify(ledgerWrites);q.push(s(env,`INSERT INTO ledger_entries(id,organization_id,agent_id,ticket_id,player_net_delta_kyat,event_type)
 SELECT json_extract(value,'$.id'),?,json_extract(value,'$.agentId'),
 json_extract(value,'$.ticketId'),json_extract(value,'$.net'),'SETTLEMENT' FROM json_each(?)`,u.organization_id,l))}
 q.push(audit(env,u,'CONFIRM_RESULT','match',mid,{state,homeGoals:d.homeGoals??null,awayGoals:d.awayGoals??null,affected:related.length}));
 // A SQLite trigger aborts whole batch if any other request already confirmed the result.
 await env.DB.batch(q);return json({affected:related.length,committed:true});
}
async function api(req,env,url){if(req.method==='POST')verifyOrigin(req);const path=url.pathname;
 if(path==='/api/login'&&req.method==='POST')return login(env,req);
 if(path==='/api/bootstrap/status'&&req.method==='GET')return bootstrapStatus(env);
 if(path==='/api/bootstrap'&&req.method==='POST')return bootstrap(env,req);
 const u=await auth(env,req);
 if(path==='/api/me'&&req.method==='GET'){role(u,'SUPER_ADMIN','ADMIN','AGENT');return json({id:u.id,name:u.display_name,email:u.email,role:u.role,organizationId:u.organization_id})}
 if(path==='/api/logout'&&req.method==='POST'){const cookie=selectedCookie(req);if(cookie)await run(env,'DELETE FROM sessions WHERE token_hash=?',await hashSha(cookie));return json({ok:true},200,{'set-cookie':'fc_sid=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict'})}
 if(path==='/api/change-password'&&req.method==='POST'){role(u,'SUPER_ADMIN','ADMIN','AGENT');return passwordChange(env,u,req)}
 if(path==='/api/dashboard'&&req.method==='GET'){role(u,'SUPER_ADMIN','ADMIN','AGENT');return dashboard(env,u)}
 if(path==='/api/tenants'&&req.method==='GET'){role(u,'SUPER_ADMIN');return tenants(env)}
 if(path==='/api/tenants'&&req.method==='POST'){role(u,'SUPER_ADMIN');return createTenant(env,u,req)}
 let m=path.match(/^\/api\/tenants\/([a-f0-9-]{36})\/(active|extend)$/);
 if(m&&req.method==='POST'){role(u,'SUPER_ADMIN');return m[2]==='active'?tenantActive(env,u,req,m[1]):tenantExtend(env,u,req,m[1])}
 if(path==='/api/agents'&&req.method==='GET'){role(u,'ADMIN');return agents(env,u)}
 if(path==='/api/agents'&&req.method==='POST'){role(u,'ADMIN');return agentCreate(env,u,req)}
 m=path.match(/^\/api\/agents\/([a-f0-9-]{36})\/active$/);
 if(m&&req.method==='POST'){role(u,'ADMIN');return agentActive(env,u,req,m[1])}
 if(path==='/api/matches'&&req.method==='GET'){role(u,'ADMIN','AGENT');return matches(env,u)}
 if(path==='/api/matches'&&req.method==='POST'){role(u,'ADMIN');return createMatch(env,u,req)}
 m=path.match(/^\/api\/matches\/([a-f0-9-]{36})\/quote$/);
 if(m&&req.method==='POST'){role(u,'ADMIN');return changeQuote(env,u,req,m[1])}
 m=path.match(/^\/api\/matches\/([a-f0-9-]{36})\/(preview|confirm)$/);
 if(m&&req.method==='POST'){role(u,'ADMIN');return settleMatch(env,u,m[1],await body(req),m[2]==='confirm')}
 if(path==='/api/tickets'&&req.method==='GET'){role(u,'ADMIN','AGENT');return tickets(env,u,url)}
 if(path==='/api/tickets'&&req.method==='POST'){role(u,'AGENT');return ticketsCreate(env,u,req)}
 if(path==='/api/reports'&&req.method==='GET'){role(u,'ADMIN','AGENT');return reports(env,u)}
 fail(404,'API not found')
}
export default {async fetch(req,env){try{const url=new URL(req.url);
 if(url.pathname==='/health'){const result=await one(env,'SELECT 1 AS ok');return json({ok:result?.ok===1})}
 if(url.pathname.startsWith('/api/'))return await api(req,env,url);
 if(req.method!=='GET'&&req.method!=='HEAD')fail(405,'Method not allowed');
 const response=await env.ASSETS.fetch(req);const h=new Headers(response.headers);
 h.set('x-content-type-options','nosniff');h.set('referrer-policy','same-origin');
 h.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
 return new Response(response.body,{status:response.status,headers:h});
 }catch(e){const status=e instanceof HttpError?e.status:/UNIQUE constraint failed|FOREIGN KEY constraint failed|CHECK constraint failed/.test(String(e.message))?409:500;
 if(status===500)console.error('Worker request error:',e);return json({error:status===500?'Server error':e instanceof HttpError?e.message:'Duplicate/conflicting record'},status)}}};
