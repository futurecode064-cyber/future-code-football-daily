// Future Code Agent Ledger V1 — rules confirmed by project owner.
// Demonstration calculation engine; production use requires reconciliation, audit and security review.
// Money: integer MMK. Calculation rates: basis points (10000 = 100%).

export function normalizeDigits(input) {
  const myanmar = '၀၁၂၃၄၅၆၇၈၉';
  return String(input ?? '').replace(/[၀-၉]/g, ch => String(myanmar.indexOf(ch))).replace(/\s+/g, '');
}

export function parseQuote(raw, marketType, giverSide = null) {
  const code = normalizeDigits(raw).toUpperCase();
  const kind = marketType === 'BODY' ? 'HANDICAP' : marketType === 'TOTAL' ? 'TOTAL' : null;
  if (!kind) throw new Error('Unknown market type');
  const isDraw = /^L([+-])(\d{1,3})$/.exec(code);
  if (isDraw && kind === 'HANDICAP') {
    const [, sign, percentText] = isDraw;
    const percent = Number(percentText);
    if (percent > 100 || sign !== '-' || code !== 'L-50') throw new Error('Draw handicap is not yet confirmed for this quote');
    if (!['HOME','AWAY'].includes(giverSide)) throw new Error('Giving team must be HOME or AWAY');
    return {code,marketType:kind,lineKind:'DRAW',lineValue:0,sign,percent,giverSide};
  }
  const match = /^(\d{1,2})([+-])(\d{1,3})$/.exec(code);
  if (!match) throw new Error('Format example: 1+35, 1-30, L-50, 3+35');
  const [, lineText, sign, percentText] = match;
  const lineValue = Number(lineText), percent = Number(percentText);
  if (percent > 100) throw new Error('Percent must not exceed 100');
  const supported = kind === 'HANDICAP'
    ? ['1+35','2+35','1-30'].includes(code)
    : code === '3+35';
  if (!supported) throw new Error('Settlement rule for '+code+' is not confirmed yet');
  if (kind === 'HANDICAP' && !['HOME','AWAY'].includes(giverSide)) throw new Error('Giving team must be HOME or AWAY');
  return {code,marketType:kind,lineKind:'GOALS',lineValue,sign,percent,giverSide:kind === 'HANDICAP' ? giverSide : null};
}

function factorFromNetRate(netBasisPoints) {
  return 10000 + netBasisPoints;
}

export function settleSelection(selection, match) {
  if (match.status === 'VOID') return {state:'VOID', factorBasisPoints:10000, netBasisPoints:0};
  if (match.status !== 'FINAL') return {state:'PENDING', factorBasisPoints:null, netBasisPoints:null};
  const home = match.homeGoals, away = match.awayGoals;
  if (![home,away].every(v => Number.isInteger(v) && v >= 0)) throw new Error('Final score must be non-negative integers');
  const {quote, pick} = selection;
  let center = 0;
  let isGivingSide = false;
  if (quote.marketType === 'HANDICAP') {
    if (!['HOME','AWAY'].includes(pick)) throw new Error('Invalid body selection');
    const giverMargin = quote.giverSide === 'HOME' ? home-away : away-home;
    isGivingSide = pick === quote.giverSide;
    if (quote.lineKind === 'DRAW') {
      center = giverMargin === 0 ? -quote.percent * 100 : giverMargin > 0 ? 10000 : -10000;
    } else {
      center = giverMargin > quote.lineValue ? 10000 : giverMargin < quote.lineValue ? -10000 : (quote.sign === '+' ? 1 : -1) * quote.percent * 100;
    }
  } else if (quote.marketType === 'TOTAL') {
    if (!['OVER','UNDER'].includes(pick)) throw new Error('Invalid goal total selection');
    const margin = home + away - quote.lineValue;
    center = margin > 0 ? 10000 : margin < 0 ? -10000 : (quote.sign === '+' ? 1 : -1) * quote.percent * 100;
    isGivingSide = pick === 'OVER';
  } else throw new Error('Unknown market type');
  const netBasisPoints = isGivingSide ? center : -center;
  return {state:'SETTLED', factorBasisPoints:factorFromNetRate(netBasisPoints), netBasisPoints};
}

// Exact fixed-point half-up rounding only at the final ticket payout.
export function settleTicket(ticket, matchLookup) {
  if (!Number.isSafeInteger(ticket.stakeKyat) || ticket.stakeKyat <= 0) throw new Error('Stake must be positive integer MMK');
  if (!Array.isArray(ticket.selections)) throw new Error('Missing selections');
  const length = ticket.selections.length;
  if (ticket.type === 'BODY' && length !== 1) throw new Error('Body ticket must have one selection');
  if (ticket.type === 'MOUNG' && (length < 4 || length > 12)) throw new Error('Moung ticket must contain 4–12 selections');
  if (!['BODY','MOUNG'].includes(ticket.type)) throw new Error('Invalid ticket type');
  if (new Set(ticket.selections.map(s => s.matchId)).size !== length) throw new Error('Only one pick per match on a moung ticket');
  const legs = ticket.selections.map(s => {
    const match = matchLookup[s.matchId];
    if (!match) throw new Error('Match not found for '+s.matchId);
    return {...settleSelection(s, match), matchId:s.matchId};
  });
  if (legs.some(l=>l.factorBasisPoints===0)) return {state:'LOST',legs,payoutKyat:0,netKyat:-ticket.stakeKyat};
  if (legs.some(l=>l.state==='PENDING')) return {state:'PENDING',legs,payoutKyat:null,netKyat:null};
  // BigInt avoids floating-point arithmetic and accumulates factors exactly.
  const base = 10000n;
  const numerator = legs.reduce((n,l)=>n*BigInt(l.factorBasisPoints),BigInt(ticket.stakeKyat));
  const denominator = base ** BigInt(legs.length);
  const payout = (numerator + denominator/2n) / denominator;
  if (payout > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('Payout exceeds maximum supported integer');
  const payoutKyat = Number(payout);
  return {state: legs.every(l=>l.state==='VOID') ? 'REFUNDED' : 'SETTLED',legs,payoutKyat,netKyat:payoutKyat-ticket.stakeKyat};
}
