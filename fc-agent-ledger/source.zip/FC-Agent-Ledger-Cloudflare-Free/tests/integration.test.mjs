import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import worker from '../src/worker.mjs';
function createEnv(){
 const sql=new DatabaseSync(':memory:');
 sql.exec(readFileSync(new URL('../migrations/0001_initial.sql',import.meta.url),'utf8'));
 const env={SETUP_TOKEN:'a-long-randomly-generated-setup-secret-1234567890',ASSETS:{fetch:async()=>new Response('assets')}};
 env.DB={
  prepare(sqlText){return {bind(...args){return {
   first:()=>sql.prepare(sqlText).get(...args)||null,
   all:()=>({results:sql.prepare(sqlText).all(...args)}),
   run:()=>({meta:{changes:Number(sql.prepare(sqlText).run(...args).changes)}}),
   _run:()=>({meta:{changes:Number(sql.prepare(sqlText).run(...args).changes)}}),
  }}}},
  async batch(q){sql.exec('BEGIN');try{const a=q.map(x=>x._run());sql.exec('COMMIT');return a}catch(e){sql.exec('ROLLBACK');throw e}}
 };
 env.__raw=sql;return env;
}
const u='https://fc-test.example';
async function send(env,path,method='GET',data,cookie=''){
 const headers={'origin':u};if(method==='POST')headers['content-type']='application/json';if(cookie)headers.cookie=cookie;
 const res=await worker.fetch(new Request(u+path,{method,headers,body:method==='POST'?JSON.stringify(data||{}):undefined}),env);
 const out=await res.json();return {status:res.status,body:out,cookie:res.headers.get('set-cookie')?.split(';')[0]||''};
}
const password='MySecurePassword123!';
async function createAdmin(env,owner,email,name){return send(env,'/api/tenants','POST',{name,email,displayName:name,password,planDays:180,planName:'PRO'},owner)}
async function login(env,email){return send(env,'/api/login','POST',{email,password})}
async function match(env,cookie,home,away){return send(env,'/api/matches','POST',{home,away,league:'Test league',kickoff:new Date(Date.now()+3600000).toISOString(),bodyCode:'1+35',totalCode:'3+35',giverSide:'HOME'},cookie)}
test('secure setup, login and two-way tenant isolation',async()=>{
 const env=createEnv();let x=await send(env,'/api/bootstrap/status');assert.deepEqual(x.body,{needsSetup:true,enabled:true});
 x=await send(env,'/api/bootstrap','POST',{setupToken:env.SETUP_TOKEN,email:'owner@ledger.test',displayName:'Owner',password});assert.equal(x.status,201,x.body.error);
 x=await send(env,'/api/bootstrap','POST',{setupToken:env.SETUP_TOKEN,email:'other@ledger.test',displayName:'Other',password});assert.notEqual(x.status,201);
 let owner=(await login(env,'owner@ledger.test')).cookie;assert.ok(owner);
 let a=await createAdmin(env,owner,'admin-a@ledger.test','Admin A');assert.equal(a.status,201,JSON.stringify(a.body));
 let b=await createAdmin(env,owner,'admin-b@ledger.test','Admin B');assert.equal(b.status,201,JSON.stringify(b.body));
 const orgA=a.body.id,orgB=b.body.id;assert.notEqual(orgA,orgB);
 let aa=await login(env,'admin-a@ledger.test');let bb=await login(env,'admin-b@ledger.test');assert.ok(aa.cookie&&bb.cookie);
 x=await send(env,'/api/tenants');assert.equal(x.status,401);
 x=await send(env,'/api/tenants','GET',undefined,aa.cookie);assert.equal(x.status,403);
 x=await send(env,'/api/agents','POST',{displayName:'Agent A',email:'agent-a@ledger.test',password},aa.cookie);assert.equal(x.status,201,JSON.stringify(x.body));const aid=x.body.id;
 x=await send(env,'/api/agents','GET',undefined,bb.cookie);assert.deepEqual(x.body,[]);
 x=await send(env,`/api/agents/${aid}/active`,'POST',{active:false},bb.cookie);assert.equal(x.status,404);
 let agent=(await login(env,'agent-a@ledger.test')).cookie;assert.ok(agent);
 const ma=await match(env,aa.cookie,'Manchester','Arsenal');assert.equal(ma.status,201,JSON.stringify(ma.body));
 x=await send(env,'/api/matches','GET',undefined,bb.cookie);assert.deepEqual(x.body,[]);
 x=await send(env,'/api/matches','GET',undefined,agent);assert.equal(x.body.length,1);
 x=await send(env,`/api/matches/${ma.body.id}/quote`,'POST',{market:'BODY',code:'1-30',giverSide:'HOME'},bb.cookie);assert.equal(x.status,404);
 // Admin can void its own match and agent stake refunds; other admin cannot change it.
 x=await send(env,`/api/matches/${ma.body.id}/preview`,'POST',{void:true},bb.cookie);assert.equal(x.status,404);
 x=await send(env,`/api/matches/${ma.body.id}/preview`,'POST',{void:true},aa.cookie);assert.equal(x.status,200);assert.equal(x.body.affected,0);
 const mb=await match(env,bb.cookie,'Chelsea','Liverpool');assert.equal(mb.status,201);
 x=await send(env,'/api/tickets','POST',{type:'BODY',stakeKyat:10000,idempotencyKey:'a-unique-idempotency-key',selections:[{matchId:mb.body.id,pick:'HOME',market:'BODY'}]},agent);assert.equal(x.status,409); // cross-tenant match must not be accepted
 x=await send(env,'/api/tickets','POST',{type:'BODY',stakeKyat:10000,idempotencyKey:'an-actually-unique-idempotency-key',selections:[{matchId:ma.body.id,pick:'HOME',market:'BODY'}]},agent);assert.equal(x.status,201,JSON.stringify(x.body));
 x=await send(env,'/api/tickets','GET',undefined,bb.cookie);assert.deepEqual(x.body,[]);
 x=await send(env,'/api/reports','GET',undefined,bb.cookie);assert.deepEqual(x.body,[]);
 x=await send(env,'/api/tickets','GET',undefined,agent);assert.equal(x.body.length,1);assert.equal(x.body[0].stake_kyat,10000);
 x=await send(env,'/api/tickets','GET',undefined,owner);assert.equal(x.status,403); // super admin not allowed sensitive bets
 x=await send(env,'/api/dashboard','GET',undefined,owner);assert.equal(x.body.organizations,2);
 x=await send(env,'/api/agents','POST',{displayName:'Bad',email:'bad@ledger.test',password},agent);assert.equal(x.status,403);
});

test('result settlement is 90-minute only, settles correctly and cannot be changed',async()=>{
 const env=createEnv();const pass=password;
 await send(env,'/api/bootstrap','POST',{setupToken:env.SETUP_TOKEN,email:'owner2@ledger.test',displayName:'Owner',password:pass});
 const owner=(await login(env,'owner2@ledger.test')).cookie;
 await createAdmin(env,owner,'admin2@ledger.test','Admin');const adm=(await login(env,'admin2@ledger.test')).cookie;
 const agentResult=await send(env,'/api/agents','POST',{displayName:'Agent',email:'agent2@ledger.test',password:pass},adm);assert.equal(agentResult.status,201);
 const agent=(await login(env,'agent2@ledger.test')).cookie;
 const m=await match(env,adm,'Manchester','Arsenal');assert.equal(m.status,201);
 const tid=await send(env,'/api/tickets','POST',{type:'BODY',stakeKyat:10000,idempotencyKey:'abc-def-1234567890',selections:[{matchId:m.body.id,pick:'HOME',market:'BODY'}]},agent);assert.equal(tid.status,201);
 let x=await send(env,`/api/matches/${m.body.id}/confirm`,'POST',{homeGoals:2,awayGoals:1},adm);assert.equal(x.status,400);
 env.__raw.prepare('UPDATE matches SET kickoff_at=? WHERE id=?').run(new Date(Date.now()-7200000).toISOString(),m.body.id);
 x=await send(env,`/api/matches/${m.body.id}/preview`,'POST',{homeGoals:2,awayGoals:1},adm);assert.equal(x.status,200);assert.equal(x.body.affected,1);assert.equal(x.body.updates[0].payout,13500);
 x=await send(env,`/api/matches/${m.body.id}/confirm`,'POST',{homeGoals:2,awayGoals:1},adm);assert.equal(x.status,200,JSON.stringify(x.body));
 x=await send(env,'/api/tickets','GET',undefined,agent);assert.equal(x.body[0].payout_kyat,13500);assert.equal(x.body[0].net_kyat,3500);
 x=await send(env,'/api/reports','GET',undefined,adm);assert.equal(x.body[0].player_net_kyat,3500);assert.equal(x.body[0].admin_net_kyat,-3500);
 x=await send(env,`/api/matches/${m.body.id}/confirm`,'POST',{homeGoals:5,awayGoals:0},adm);assert.equal(x.status,409);
});

test('bulk settlement of 120 tickets stays within few D1 statements and reports totals',async()=>{
 const env=createEnv();await send(env,'/api/bootstrap','POST',{setupToken:env.SETUP_TOKEN,email:'bigowner@ledger.test',displayName:'Owner',password});
 const owner=(await login(env,'bigowner@ledger.test')).cookie;
 await createAdmin(env,owner,'bigadmin@ledger.test','Admin Bulk');const adm=(await login(env,'bigadmin@ledger.test')).cookie;
 await send(env,'/api/agents','POST',{displayName:'Agent Bulk',email:'bulk-agent@ledger.test',password},adm);
 const a=(await login(env,'bulk-agent@ledger.test')).cookie;
 const fixture=await match(env,adm,'Manchester','Chelsea');assert.equal(fixture.status,201);
 const mid=fixture.body.id;
 const raw=env.__raw;const {id:oid}=raw.prepare('SELECT id FROM organizations').get();
 const {id:uid}=raw.prepare("SELECT id FROM users WHERE role='AGENT'").get();
 const {id:qid}=raw.prepare("SELECT id FROM odds_quotes WHERE match_id=? AND market='BODY'").get(mid);
 const quote={code:'1+35',marketType:'HANDICAP',lineKind:'GOALS',lineValue:1,sign:'+',percent:35,giverSide:'HOME'};
 const insertT=raw.prepare('INSERT INTO tickets(id,organization_id,ticket_number,agent_id,ticket_type,stake_kyat,idempotency_key) VALUES(?,?,?,?,?,?,?)');
 const insertS=raw.prepare('INSERT INTO ticket_selections(id,organization_id,ticket_id,match_id,quote_id,position,chosen_side,quote_snapshot) VALUES(?,?,?,?,?,?,?,?)');
 for(let i=0;i<120;i++){const tid=crypto.randomUUID();insertT.run(tid,oid,`BULK-${i}`,uid,'BODY',10000,`bulk-${i}`);insertS.run(crypto.randomUUID(),oid,tid,mid,qid,1,'HOME',JSON.stringify(quote))}
 raw.prepare('UPDATE matches SET kickoff_at=? WHERE id=?').run(new Date(Date.now()-7200000).toISOString(),mid);
 const preview=await send(env,`/api/matches/${mid}/preview`,'POST',{homeGoals:2,awayGoals:1},adm);assert.equal(preview.status,200,JSON.stringify(preview.body));assert.equal(preview.body.affected,120);
 const confirmed=await send(env,`/api/matches/${mid}/confirm`,'POST',{homeGoals:2,awayGoals:1},adm);assert.equal(confirmed.status,200,JSON.stringify(confirmed.body));
 const summary=await send(env,'/api/reports','GET',undefined,adm);assert.equal(summary.body[0].tickets,120);assert.equal(summary.body[0].player_net_kyat,120*3500);
 const history=await send(env,'/api/tickets','GET',undefined,a);assert.equal(history.status,200);assert.equal(history.body.length,120);
 const ledgers=raw.prepare('SELECT COUNT(*) n FROM ledger_entries').get();assert.equal(ledgers.n,120);
});
