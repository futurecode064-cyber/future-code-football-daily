import {test} from 'node:test';
import assert from 'node:assert/strict';
import {normalizeDigits,parseQuote,settleSelection,settleTicket} from '../src/settlement.mjs';
const final=(homeGoals,awayGoals)=>({status:'FINAL',homeGoals,awayGoals});
const leg=(matchId,market,price,giver,pick)=>({matchId,quote:parseQuote(price,market,giver),pick});
const factor=(price,market,giver,pick,home,away)=>settleSelection(leg('M',market,price,giver,pick),final(home,away)).factorBasisPoints;

test('Myanmar digits and body +35 partial win',()=>{
  assert.equal(normalizeDigits('၁+၃၅'),'1+35');
  assert.equal(factor('၁+၃၅','BODY','HOME','HOME',2,1),13500);
  assert.equal(factor('၁+၃၅','BODY','HOME','AWAY',2,1),6500);
  assert.equal(factor('1+35','BODY','HOME','HOME',2,0),20000);
  assert.equal(factor('1+35','BODY','HOME','HOME',1,1),0);
});
test('2+35 under threshold and exactly threshold',()=>{
  assert.equal(factor('2+35','BODY','HOME','HOME',2,1),0);
  assert.equal(factor('2+35','BODY','HOME','HOME',2,0),13500);
  assert.equal(factor('2+35','BODY','HOME','HOME',4,1),20000);
  assert.equal(factor('2+35','BODY','HOME','AWAY',2,0),6500);
});
test('1-30 on one goal: favored loses 30%, opposite gains 30%',()=>{
  assert.equal(factor('1-30','BODY','HOME','HOME',2,1),7000);
  assert.equal(factor('1-30','BODY','HOME','AWAY',2,1),13000);
  assert.equal(factor('1-30','BODY','HOME','HOME',2,0),20000);
});
test('L-50 draw and result based on giving team',()=>{
  assert.equal(factor('L-50','BODY','AWAY','AWAY',1,1),5000);
  assert.equal(factor('L-50','BODY','AWAY','HOME',1,1),15000);
  assert.equal(factor('L-50','BODY','AWAY','AWAY',1,2),20000);
  assert.equal(factor('L-50','BODY','AWAY','AWAY',2,1),0);
});
test('3+35 combined total goals',()=>{
  assert.equal(factor('3+35','TOTAL',null,'OVER',2,1),13500);
  assert.equal(factor('3+35','TOTAL',null,'UNDER',2,1),6500);
  assert.equal(factor('3+35','TOTAL',null,'OVER',1,1),0);
  assert.equal(factor('3+35','TOTAL',null,'UNDER',1,1),20000);
  assert.equal(factor('3+35','TOTAL',null,'OVER',3,1),20000);
});
test('single-stake parlay with void at 1.00: 18,900 payout',()=>{
  const picks=[leg('A','BODY','1+35','HOME','HOME'),leg('B','TOTAL','3+35',null,'OVER'),leg('C','BODY','L-50','HOME','HOME'),leg('D','BODY','1-30','HOME','HOME'),leg('E','BODY','1+35','HOME','HOME')];
  // A=2, B=1.35, C=void=1.00, D=.70, E=2.00.
  const lookup={A:final(3,0),B:final(2,1),C:{status:'VOID'},D:final(1,0),E:final(3,1)};
  const ticket={type:'MOUNG',stakeKyat:5000,selections:picks};
  const outcome=settleTicket(ticket,lookup);
  assert.equal(outcome.payoutKyat,18900);
  assert.equal(outcome.netKyat,13900);
});
test('one full-loss leg zeros entire parlay; all void returns stake',()=>{
  const picks=['A','B','C','D'].map(k=>leg(k,'BODY','1+35','HOME','HOME'));
  assert.equal(settleTicket({type:'MOUNG',stakeKyat:5000,selections:picks},{A:final(0,0),B:final(2,0),C:final(3,0),D:{status:'SCHEDULED'}}).payoutKyat,0);
  const allVoid=Object.fromEntries(['A','B','C','D'].map(k=>[k,{status:'VOID'}]));
  assert.deepEqual({...settleTicket({type:'MOUNG',stakeKyat:5000,selections:picks},allVoid),legs:[]},{state:'REFUNDED',payoutKyat:5000,netKyat:0,legs:[]});
});
test('pending and unsupported odds cannot silently settle',()=>{
  assert.equal(settleSelection(leg('A','BODY','1+35','HOME','HOME'),{status:'SCHEDULED'}).state,'PENDING');
  assert.throws(()=>parseQuote('0+50','BODY','HOME'),/not confirmed/);
  assert.throws(()=>settleTicket({type:'MOUNG',stakeKyat:5000,selections:[]},{}),/4–12/);
});
