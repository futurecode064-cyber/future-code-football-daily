'use strict';
const root=document.getElementById('root');
const S={user:null,view:'dashboard',data:{},notice:'',error:'',ticketAgentId:'',busy:false,bootstrap:false,setupAvailable:false};
const e=(v)=>String(v??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const cash=n=>n===null||n===undefined?'—':Number(n).toLocaleString('en-US')+' Ks';
const signed=n=>n===null||n===undefined?'—':`${Number(n)>0?'+':''}${cash(n)}`;
const time=t=>new Date(t).toLocaleString('en-GB',{timeZone:'Asia/Yangon',day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
const escAttr=e;
const badge=(t,color='gold')=>`<span class="pill ${color}">${e(t)}</span>`;
const nstate=s=>({PENDING:'ရလဒ်စောင့်',SETTLED:'ပြီးဆုံး',LOST:'ရှုံး',REFUNDED:'Refund'})[s]||s;
const pickLabel=k=>({HOME:'အိမ်ရှင် ဘော်ဒီ',AWAY:'အဝေးအသင်း ဘော်ဒီ',OVER:'ဂိုးပေါ်',UNDER:'ဂိုးအောက်'})[k]||k;
const canPick=m=>m.status==='SCHEDULED'&&new Date(m.kickoff_at)>new Date();
const pickMarket=p=>['HOME','AWAY'].includes(p)?'BODY':'TOTAL';
async function api(path,method='GET',data){
 const r=await fetch('/api'+path,{method,credentials:'same-origin',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined});
 const json=await r.json().catch(()=>({error:'Response invalid'}));if(!r.ok)throw new Error(json.error||'Server error');return json;
}
function pop(message,error=false){S[error?'error':'notice']=message;S[error?'notice':'error']='';render()}
function formFields(d){return Object.fromEntries(new FormData(d).entries())}
const navs={SUPER_ADMIN:[['dashboard','Dashboard'],['tenants','Admin Accounts'],['password','Password']],ADMIN:[['dashboard','Dashboard'],['matches','ပွဲစဉ် / ကြေး'],['agents','Agent Accounts'],['tickets','Ticket History'],['reports','စာရင်းချုပ်'],['password','Password']],AGENT:[['dashboard','Dashboard'],['matches','ပွဲစဉ်များ'],['body','ဘော်ဒီ'],['moung','မောင်း'],['tickets','Ticket History'],['reports','စာရင်းချုပ်'],['password','Password']]};
function loginHTML(){return `<main class="login-wrap"><section class="login"><div class="brand-logo">FC</div><h1>Agent Ledger</h1><p class="muted">Future Code AI Studio · Private Account Login</p><div id="flash">${flash()}</div>
${S.bootstrap?`<form id="setup-form"><div class="field"><label>Setup Token (hosting secret)</label><input name="setupToken" type="password" required></div><div class="field"><label>Owner Name</label><input name="displayName" required></div><div class="field"><label>Owner Email</label><input type="email" name="email" required></div><div class="field"><label>New Password</label><input type="password" name="password" minlength="12" required></div><button class="btn primary full mt">Create Super Admin</button></form>`:`<form id="login-form"><div class="field"><label>Email Address</label><input name="email" type="email" autocomplete="username" required></div><div class="field"><label>Password</label><input name="password" type="password" autocomplete="current-password" required></div><button class="btn primary full mt" type="submit">အကောင့်ဝင်ရန်</button></form>`}${S.setupAvailable?`<button type="button" class="btn full mt" data-action="toggle-setup">${S.bootstrap?"Back to Login":"First-time Super Admin Setup"}</button>`:""}<div class="login-footer">Super Admin → Admin → Agent · Secure tenant isolation</div></section></main>`}
function flash(){const s=S.error?`<div class="alert">${e(S.error)}</div>`:S.notice?`<div class="notice">${e(S.notice)}</div>`:'';S.notice='';S.error='';return s}
function layout(){const menus=navs[S.user.role]||[];
 return `<div class="shell"><aside class="sidebar"><div class="brand"><div class="brand-logo">FC</div><div><strong>AGENT LEDGER</strong><br><small>Future Code AI Studio</small></div></div><nav>${menus.map(([k,v])=>`<button class="nav-btn ${S.view===k?'active':''}" data-view="${k}">${e(v)}</button>`).join('')}</nav><div class="side-bottom">Account isolation enabled<br>Myanmar Time · MMK</div></aside>
 <main class="main"><header class="topbar"><div><h2>${e(menus.find(x=>x[0]===S.view)?.[1]||'Dashboard')}</h2><p class="title-helper">${S.user.role==='SUPER_ADMIN'?'Platform Owner':S.user.role==='ADMIN'?'Bookie Admin':'Agent'} Portal</p></div><div class="user"><div class="role">${e(S.user.role)}</div><b>${e(S.user.name)}</b> · ${e(S.user.email)}</div><button class="btn small" data-action="logout">Logout</button></header><div id="flash">${flash()}</div><div id="page">${page()}</div></main></div>`}
function page(){switch(S.view){case 'dashboard':return dashboard();case 'password':return passwordPage();case 'tenants':return tenants();case 'matches':return matches();case 'agents':return agents();case 'tickets':return tickets();case 'reports':return reports();case 'body':return betForm('BODY');case 'moung':return betForm('MOUNG');default:return dashboard()}}
function passwordPage(){return `<section class="panel" style="max-width:550px"><h3>ကိုယ်ပိုင် Password ပြောင်းရန်</h3><p class="hint">Account အသစ်ဖွင့်ပြီး ပေးထားတဲ့ Temporary Password ကို ကိုယ်တိုင်ပြောင်းထားပါ။ အနည်းဆုံး 12 characters လိုပါတယ်။</p><form id="password-form"><div class="field"><label>Current Password</label><input type="password" name="currentPassword" autocomplete="current-password" required></div><div class="field"><label>New Password</label><input type="password" name="newPassword" autocomplete="new-password" minlength="12" required></div><div class="field"><label>Confirm New Password</label><input type="password" name="confirmPassword" autocomplete="new-password" minlength="12" required></div><button class="btn primary">Change Password</button></form></section>`}
function dashboard(){const d=S.data.dashboard||{};
 if(S.user.role==='SUPER_ADMIN')return `<div class="grid three"><div class="stat"><small>Admin Organizations</small><strong>${e(d.organizations??0)}</strong></div><div class="stat"><small>Active Organizations</small><strong class="green">${e(d.active_organizations??0)}</strong></div><div class="stat"><small>Active Admin Users</small><strong>${e(d.admins??0)}</strong></div></div><section class="panel mt"><h3>Super Admin Control</h3><p class="muted">Admin အကောင့်အသစ်တစ်ခု ဖန်တီးတိုင်း သီးသန့် Organization ID ပေးမယ်။ အခြား Admin ရဲ့ Ticket/Agent ဒေတာတွေကို Platform Dashboard က ဖော်ပြမထားပါ။</p><button class="btn primary" data-view="tenants">Admin Accounts စီမံမယ်</button></section>`;
 return `<div class="grid three"><div class="stat"><small>စာရင်းစောင်</small><strong>${e(d.tickets??0)}</strong></div><div class="stat"><small>ရလဒ်စောင့်</small><strong>${e(d.pending??0)}</strong></div><div class="stat"><small>လောင်းငွေ စုစုပေါင်း</small><strong>${cash(d.stakes_kyat||0)}</strong></div></div>
 <section class="panel mt"><h3>အသားတင်အမြတ်အရှုံး</h3><div class="big-num ${Number(d.player_net_kyat)>=0?'green':'red'}">${signed(d.player_net_kyat||0)}</div><p class="hint">${S.user.role==='ADMIN'?'Agent/player perspective မှတွက်ထားသည်။ ဒိုင်ဘက် အမြတ်အရှုံးက အပေါင်း/အနုတ် ပြောင်းပြန်ဖြစ်မည်။':'Agent/player perspective'}</p><div class="actions"><button class="btn" data-view="tickets">စာရင်းစောင်များ</button><button class="btn" data-view="reports">စာရင်းချုပ်</button></div></section>`}
function tenants(){const ts=S.data.tenants||[];return `<div class="grid two"><section class="panel"><h3>Admin အသစ် ဖွင့်ရန်</h3><p class="hint">Admin တစ်ယောက်ချင်းစီအတွက် သီးသန့် Data Space ဖန်တီးမယ်။</p>
<form id="tenant-form"><div class="field"><label>ဒိုင်လုပ်ငန်းအမည်</label><input name="name" required maxlength="150" placeholder="ဥပမာ – Bookie One"></div>
<div class="field"><label>Admin အမည်</label><input name="displayName" required maxlength="100"></div><div class="field"><label>Admin Email</label><input name="email" type="email" required></div><div class="row-form"><div class="field"><label>Package Name</label><input name="planName" value="STANDARD" required></div><div class="field"><label>သက်တမ်း (ရက်)</label><input type="number" name="planDays" value="30" min="1" max="3660" required></div></div><div class="field"><label>Temporary Password (12+ characters)</label><input name="password" type="password" minlength="12" required autocomplete="new-password"></div><button class="btn primary full">Admin Account ဖွင့်မယ်</button></form></section>
<section class="panel"><div class="toolbar"><h3>သီးသန့် Admin Accounts</h3>${badge(ts.length+' Organizations')}</div>
${ts.length?ts.map(t=>`<div class="match-row"><div class="flex"><b>${e(t.name)}</b>${badge(t.active?'Active':'Suspended',t.active?'green':'red')}</div><p class="match-meta">${e(t.plan_name)} · Admin: ${e(t.admins)} · Agent: ${e(t.agents)} · Expiry: ${t.expires_at?time(t.expires_at):"Unlimited"}</p><button class="btn small ${t.active?'danger':''}" data-action="toggle-tenant" data-id="${escAttr(t.id)}" data-active="${t.active?'false':'true'}">${t.active?'Suspend':'Reactivate'}</button> <button class="btn small" data-action="extend-tenant" data-id="${escAttr(t.id)}">သက်တမ်းတိုး</button></div>`).join(''):'<div class="empty">Admin Account မရှိသေးပါ</div>'}</section></div>`}
function agents(){const as=S.data.agents||[];return `<div class="grid two"><section class="panel"><h3>Agent အသစ်ဖွင့်ရန်</h3><form id="agent-form"><div class="field"><label>အေးဂျင့်အမည်</label><input name="displayName" required></div><div class="field"><label>Agent Email</label><input type="email" name="email" required></div><div class="field"><label>Temporary Password</label><input name="password" type="password" minlength="12" autocomplete="new-password" required></div><button class="btn primary full">Agent Account ဖွင့်မယ်</button></form></section>
<section class="panel"><div class="toolbar"><h3>ကိုယ့် Agent စာရင်း</h3>${badge(as.length+' Agents')}</div>${as.length?as.map(a=>`<div class="match-row"><div class="flex"><b>${e(a.display_name)}</b>${badge(a.active?'Active':'Disabled',a.active?'green':'red')}</div><p class="match-meta">${e(a.email)}</p><div class="actions"><button class="btn small" data-action="agent-tickets" data-id="${escAttr(a.id)}">စာရင်းကြည့်</button><button class="btn small ${a.active?'danger':''}" data-action="toggle-agent" data-id="${escAttr(a.id)}" data-active="${a.active?'false':'true'}">${a.active?'Disable':'Enable'}</button></div></div>`).join(''):'<div class="empty">အေးဂျင့် မဖွင့်ရသေးပါ</div>'}</section></div>`}
function matches(){const ms=S.data.matches||[];const admin=S.user.role==='ADMIN';return `${admin?`<section class="panel"><h3>ဒီနေ့ / နောက်ပွဲစဉ် အသစ်ထည့်ရန်</h3><form id="match-form"><div class="row-form"><div class="field"><label>League</label><input name="league" placeholder="Premier League"></div><div class="field"><label>ပွဲချိန် (မြန်မာစံတော်ချိန်)</label><input type="datetime-local" name="kickoff" required></div><div class="field"><label>အိမ်ရှင်အသင်း</label><input name="home" required></div><div class="field"><label>အဝေးအသင်း</label><input name="away" required></div><div class="field"><label>ဘော်ဒီကြေးပေးအသင်း</label><select name="giverSide"><option value="HOME">အိမ်ရှင်</option><option value="AWAY">အဝေးအသင်း</option></select></div><div class="field"><label>ဘော်ဒီကြေး</label><select name="bodyCode"><option>1+35</option><option>2+35</option><option>1-30</option><option>L-50</option></select></div><div class="field"><label>ဂိုးပေါင်းကြေး</label><select name="totalCode"><option>3+35</option></select></div></div><button class="btn primary">ပွဲစဉ်သိမ်းမယ်</button></form><p class="hint">ကြေးအသစ် ထည့်ပြင်လည်း လက်ခံပြီးသား Ticket ထဲက မူလကြေး မပြောင်းပါ။ လက်ရှိ အတည်ပြုထားတဲ့ ကြေး Code တွေကိုသာ ဖွင့်ထားပါတယ်။</p></section>`:''}
 <section class="panel mt"><div class="toolbar"><h3>ပွဲစဉ်များ</h3>${badge(ms.length+' Matches')}</div>${ms.length?ms.map(m=>matchCard(m,admin)).join(''):'<div class="empty">ပွဲစဉ် မရှိသေးပါ</div>'}</section>`}
function matchCard(m,admin){return `<div class="match-row"><div class="match-head"><div><small class="muted">${e(m.league)}</small><div class="match-title">${e(m.home_team)} <span class="gold">VS</span> ${e(m.away_team)}</div><div class="match-meta">${time(m.kickoff_at)} · ဘော်ဒီ ${e(m.body_code||'—')} (${m.giver_side==='HOME'?'အိမ်ရှင်':'အဝေး'}) · ဂိုးပေါင်း ${e(m.total_code||'—')}</div></div>${badge(m.status==='FINAL'?`${m.home_goals_90}–${m.away_goals_90}`:m.status,m.status==='FINAL'?'green':'gold')}</div>
 ${admin&&m.status==='SCHEDULED'?`<div class="match-actions"><button class="btn small" data-action="edit-quote" data-id="${escAttr(m.id)}">ကြေးပြင်</button><button class="btn small" data-action="set-result" data-id="${escAttr(m.id)}">ဂိုးရလဒ် / ပွဲဖျက်</button></div>`:''}</div>`}
function betForm(type){const ms=(S.data.matches||[]).filter(canPick);if(!ms.length)return `<div class="empty">လောင်းစာရင်းထည့်နိုင်တဲ့ ပွဲမရှိပါ။ Admin ကို ပွဲစဉ်ဖြည့်ခိုင်းပါ။</div>`;
 const opts=ms.map(m=>`<option value="${escAttr(m.id)}">${e(m.home_team)} vs ${e(m.away_team)} · ${time(m.kickoff_at)}</option>`).join('');
 const choices=picks=>`<option value="">— မရွေး —</option><option value="HOME">${e('အိမ်ရှင် ဘော်ဒီ')}</option><option value="AWAY">အဝေးအသင်း ဘော်ဒီ</option><option value="OVER">ဂိုးပေါ်</option><option value="UNDER">ဂိုးအောက်</option>`;
 return `<section class="panel"><h3>${type==='BODY'?'ဘော်ဒီ တစ်ပွဲစာရင်း':'မောင်း ၄–၁၂ ပွဲတွဲ'}</h3><p class="hint">${type==='MOUNG'?'မောင်းတစ်စောင်လုံးအတွက် လောင်းငွေ တစ်ကြိမ်ပဲ ထည့်ပါ။ ပွဲတစ်ပွဲချင်းငွေ မထည့်ပါ။':'ပွဲတစ်ပွဲရွေးပြီး ရွေးချယ်မှုနဲ့ လောင်းငွေ ဖြည့်ပါ။'}</p>
 <form id="bet-form" data-type="${type}"><div class="field"><label>လောင်းငွေ (ကျပ်)</label><input name="stakeKyat" type="number" min="1" max="1000000000" step="1" required placeholder="5000"></div>
 ${type==='BODY'?`<div class="field"><label>ပွဲစဉ်</label><select name="matchId">${opts}</select></div><div class="field"><label>ရွေးချယ်မှု</label><select name="pick">${choices()}</select></div>`:
 `${ms.map(m=>`<div class="leg-row"><div class="match-head"><div><b>${e(m.home_team)} - ${e(m.away_team)}</b><div class="match-meta">${time(m.kickoff_at)} · ${e(m.body_code)} / ${e(m.total_code)}</div></div><div style="min-width:140px;width:180px"><select class="moung-pick" data-match-id="${escAttr(m.id)}">${choices()}</select></div></div>`).join('')}`}
 <div class="actions mt"><button class="btn primary">Ticket သိမ်းမယ်</button>${type==='MOUNG'?badge('4–12 unique matches'):''}</div></form></section>`}
function tickets(){const ts=S.data.tickets||[];return `<section class="panel"><div class="toolbar"><h3>${S.ticketAgentId?'Agent သီးသန့်':'Ticket History'}</h3>${S.ticketAgentId?'<button class="btn small" data-action="all-tickets">အားလုံးကြည့်</button>':''}${badge(ts.length+' Tickets')}</div>
 ${ts.length?ts.map(t=>ticketCard(t)).join(''):'<div class="empty">Ticket မရှိသေးပါ</div>'}</section>`}
function ticketCard(t){const net=t.net_kyat===null?'—':signed(t.net_kyat);return `<div class="ticket"><div class="ticket-head"><div><b>${e(t.ticket_number)}</b> · ${badge(t.ticket_type==='BODY'?'ဘော်ဒီ':'မောင်း '+(t.selections||[]).length+' ပွဲ')}
 <div class="match-meta">${time(t.accepted_at)}${S.user.role==='ADMIN'?' · '+e(t.agent_name):''}</div></div>${badge(nstate(t.status),t.status==='LOST'?'red':t.status==='PENDING'?'gold':'green')}</div>
 ${(t.selections||[]).map(l=>`<div class="leg"><span>${e(l.home_team)} - ${e(l.away_team)}<br><span class="muted">${pickLabel(l.chosen_side)} · ${e(l.quote_snapshot?.code||'')}</span></span><span class="right">${l.match_status==='FINAL'?e(l.home_goals_90)+'–'+e(l.away_goals_90):e(l.match_status)}<br><span class="muted">${l.factor_bp==null?'—':(Number(l.factor_bp)/10000).toFixed(2)+'×'}</span></span></div>`).join('')}
 <div class="ticket-total"><span>လောင်းငွေ <b>${cash(t.stake_kyat)}</b></span><span>ပြန်ရငွေ <b>${cash(t.payout_kyat)}</b></span><span>အသားတင် <b class="${Number(t.net_kyat)>=0?'green':'red'}">${net}</b></span></div></div>`}
function reports(){const rows=S.data.reports||[];return `<section class="panel"><div class="toolbar"><h3>Agent အလိုက်စာရင်းချုပ်</h3>${badge('Player / Admin Balance')}</div><div class="table-wrap"><table><thead><tr><th>အေးဂျင့်</th><th>Ticket</th><th>လောင်းငွေ</th><th>Agent ရလဒ်</th><th>ဒိုင် ရလဒ်</th><th></th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${e(r.display_name)}</b><div class="match-meta">${e(r.email)}</div></td><td>${e(r.tickets)} (${e(r.pending)} pending)</td><td>${cash(r.total_stake_kyat)}</td><td class="${Number(r.player_net_kyat)>=0?'green':'red'}">${signed(r.player_net_kyat)}</td><td class="${Number(r.admin_net_kyat)>=0?'green':'red'}">${signed(r.admin_net_kyat)}</td><td>${S.user.role==='ADMIN'?`<button class="btn small" data-action="agent-tickets" data-id="${escAttr(r.id)}">အသေးစိတ်</button>`:''}</td></tr>`).join('')||'<tr><td colspan="6" class="muted">စာရင်းမရှိသေးပါ</td></tr>'}</tbody></table></div>
 <p class="hint">Agent ရလဒ် = Player ရဲ့ အသားတင်ငွေ။ ဒိုင် ရလဒ် = Agent ရလဒ်၏ ပြောင်းပြန်။ စာရင်းတွေက settled ticket တွေကိုသာ အခြေခံပြီး ငွေပေးချေမှုများ မပါသေးပါ။</p></section>`}
function render(){root.innerHTML=S.user?layout():loginHTML()}
async function load(){
 if(!S.user)return render();
 const wants={dashboard:['dashboard'],tenants:['tenants'],agents:['agents'],matches:['matches'],body:['matches'],moung:['matches'],tickets:['tickets'],reports:['reports']}[S.view]||['dashboard'];
 try{for(const key of wants){S.data[key]=await api('/'+key+(key==='tickets'&&S.ticketAgentId?'?agentId='+encodeURIComponent(S.ticketAgentId):''))}render()}catch(err){pop(err.message,true)}
}
async function goto(v){S.view=v;if(v!=='tickets')S.ticketAgentId='';await load()}
async function actionRun(fn){if(S.busy)return;S.busy=true;try{await fn()}catch(err){pop(err.message,true)}finally{S.busy=false}}
async function init(){try{S.user=await api('/me')}catch{S.user=null}if(!S.user){try{const x=await api('/bootstrap/status');S.setupAvailable=x.needsSetup&&x.enabled}catch{}}await load()}
root.addEventListener('click',async evt=>{
 const v=evt.target.closest('[data-view]');if(v){await goto(v.dataset.view);return}
 const b=evt.target.closest('[data-action]');if(!b)return;
 const a=b.dataset.action,id=b.dataset.id;
 await actionRun(async()=>{
  if(a==='toggle-setup'){S.bootstrap=!S.bootstrap;return render()}
  if(a==='logout'){await api('/logout','POST',{});S.user=null;S.view='dashboard';return render()}
  if(a==='toggle-tenant'){await api('/tenants/'+id+'/active','POST',{active:b.dataset.active==='true'});S.notice='Account status updated';return load()}
  if(a==='extend-tenant'){const n=prompt('သက်တမ်း ဘယ်နှရက်တိုးမလဲ?', '30');if(n===null)return;await api('/tenants/'+id+'/extend','POST',{addDays:Number(n)});S.notice='Subscription သက်တမ်းတိုးပြီး';return load()}
  if(a==='toggle-agent'){await api('/agents/'+id+'/active','POST',{active:b.dataset.active==='true'});S.notice='Agent status updated';return load()}
  if(a==='agent-tickets'){S.ticketAgentId=id;S.view='tickets';return load()}
  if(a==='all-tickets'){S.ticketAgentId='';return load()}
  if(a==='edit-quote'){
   const m=(S.data.matches||[]).find(x=>x.id===id);if(!m)return;
   const market=prompt('ကြေးအမျိုးအစား BODY သို့မဟုတ် TOTAL','BODY');if(!market)return;
   const normalized=market.trim().toUpperCase();if(!['BODY','TOTAL'].includes(normalized))throw new Error('BODY/TOTAL only');
   const code=prompt('အသစ်ပြောင်းမယ့် ကြေး',normalized==='BODY'?m.body_code:m.total_code);if(!code)return;
   let giverSide=m.giver_side;
   if(normalized==='BODY'){const newSide=prompt('ကြေးပေးအသင်း HOME / AWAY',m.giver_side);if(!newSide)return;giverSide=newSide.trim().toUpperCase()}
   await api('/matches/'+id+'/quote','POST',{market:normalized,code:code.trim().toUpperCase(),giverSide});S.notice='ကြေး Version အသစ်သိမ်းပြီး';return load();
  }
  if(a==='set-result'){
   const isVoid=confirm('ဒီပွဲကို VOID / ပွဲဖျက် အဖြစ်သတ်မှတ်မလား? Cancel နှိပ်ရင် ပွဲပြီးဂိုးရလဒ် ဖြည့်နိုင်တယ်');
   let d={void:isVoid};if(!isVoid){const h=prompt('ပုံမှန်မိနစ် ၉၀ + Stoppage time အိမ်ရှင်ဂိုး');if(h===null)return;const aw=prompt('အဝေးအသင်းဂိုး');if(aw===null)return;d={homeGoals:Number(h),awayGoals:Number(aw),void:false}}
   const p=await api('/matches/'+id+'/preview','POST',d);
   if(!confirm(`စာရင်းစောင် ${p.affected} စောင်ကို ပြန်တွက်မယ်။ အတည်ပြုမလား? (နောက်ပိုင်း Result ပြင်ဆင်ခြင်းကို V1 မှာ ပိတ်ထားတယ်)`))return;
   await api('/matches/'+id+'/confirm','POST',d);S.notice='ရလဒ်အတည်ပြုပြီး';return load();
  }
 });
});
root.addEventListener('submit',async evt=>{
 const f=evt.target;if(!(f instanceof HTMLFormElement))return;evt.preventDefault();
 await actionRun(async()=>{
  const d=formFields(f);
  if(f.id==='setup-form'){await api('/bootstrap','POST',d);S.bootstrap=false;S.setupAvailable=false;S.notice='Super Admin အကောင့်ဖွင့်ပြီး။ Hosting မှ SETUP_TOKEN ဖယ်ရှားပါ။';return render()}
  if(f.id==='login-form'){S.user=(await api('/login','POST',d)).user;S.view='dashboard';S.notice='Welcome';return load()}
  if(f.id==='password-form'){if(d.newPassword!==d.confirmPassword)throw new Error('Password အတည်ပြုချက် မတူပါ');await api('/change-password','POST',d);S.notice='Password ပြောင်းပြီး';return render()}
  if(f.id==='tenant-form'){await api('/tenants','POST',d);S.notice='Admin Account အသစ်ဖွင့်ပြီး';return load()}
  if(f.id==='agent-form'){await api('/agents','POST',d);S.notice='Agent Account အသစ်ဖွင့်ပြီး';return load()}
  if(f.id==='match-form'){await api('/matches','POST',d);S.notice='ပွဲစဉ်အသစ် သိမ်းပြီး';return load()}
  if(f.id==='bet-form'){
   const type=f.dataset.type;const stakeKyat=Number(d.stakeKyat);
   const selections=type==='BODY'?[{matchId:d.matchId,pick:d.pick,market:pickMarket(d.pick)}]:Array.from(f.querySelectorAll('.moung-pick')).filter(x=>x.value).map(x=>({matchId:x.dataset.matchId,pick:x.value,market:pickMarket(x.value)}));
   if(type==='BODY'&&!d.pick)throw new Error('ရွေးချယ်မှုလိုအပ်ပါတယ်');
   if(type==='MOUNG'&&(selections.length<4||selections.length>12))throw new Error('မောင်း ၄–၁၂ ပွဲရွေးပါ');
   const key=crypto.randomUUID();await api('/tickets','POST',{type,stakeKyat,selections,idempotencyKey:key});S.view='tickets';S.notice='Ticket လက်ခံပြီး';return load();
  }
 });
});
init();
