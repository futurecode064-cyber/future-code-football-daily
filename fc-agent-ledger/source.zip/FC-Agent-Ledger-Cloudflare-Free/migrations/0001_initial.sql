PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS organizations (
 id TEXT PRIMARY KEY, name TEXT NOT NULL,
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 plan_name TEXT NOT NULL DEFAULT 'STANDARD',
 expires_at TEXT, created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, organization_id TEXT REFERENCES organizations(id),
 email TEXT NOT NULL COLLATE NOCASE UNIQUE, display_name TEXT NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('SUPER_ADMIN','ADMIN','AGENT')),
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 failed_logins INTEGER NOT NULL DEFAULT 0, locked_until TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 UNIQUE(id,organization_id),
 CHECK ((role='SUPER_ADMIN' AND organization_id IS NULL) OR
  (role IN ('ADMIN','AGENT') AND organization_id IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS only_one_owner ON users(role) WHERE role='SUPER_ADMIN';
CREATE INDEX IF NOT EXISTS users_org_role ON users(organization_id,role,active);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),
 expires_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS session_users ON sessions(user_id);
CREATE TABLE IF NOT EXISTS matches (
 id TEXT PRIMARY KEY,organization_id TEXT NOT NULL REFERENCES organizations(id),
 league TEXT NOT NULL DEFAULT '',home_team TEXT NOT NULL,away_team TEXT NOT NULL,
 kickoff_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'SCHEDULED'
 CHECK(status IN ('SCHEDULED','FINAL','VOID')),
 home_goals_90 INTEGER CHECK(home_goals_90>=0),away_goals_90 INTEGER CHECK(away_goals_90>=0),
 created_by TEXT NOT NULL REFERENCES users(id),settled_at TEXT,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 UNIQUE(id,organization_id),
 CHECK(status!='FINAL' OR (home_goals_90 IS NOT NULL AND away_goals_90 IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS matches_org_kickoff ON matches(organization_id,kickoff_at DESC);
CREATE TABLE IF NOT EXISTS odds_quotes (
 id TEXT PRIMARY KEY,organization_id TEXT NOT NULL,match_id TEXT NOT NULL,
 market TEXT NOT NULL CHECK(market IN ('BODY','TOTAL')),
 quote_code TEXT NOT NULL,giver_side TEXT CHECK(giver_side IN ('HOME','AWAY') OR giver_side IS NULL),
 revision INTEGER NOT NULL CHECK(revision>0),active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 created_by TEXT NOT NULL REFERENCES users(id),
 UNIQUE(id,organization_id),UNIQUE(match_id,market,revision),
 FOREIGN KEY(match_id,organization_id) REFERENCES matches(id,organization_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS active_quote_per_market ON odds_quotes(match_id,market) WHERE active=1;
CREATE TABLE IF NOT EXISTS tickets (
 id TEXT PRIMARY KEY,organization_id TEXT NOT NULL REFERENCES organizations(id),
 ticket_number TEXT NOT NULL,agent_id TEXT NOT NULL,
 ticket_type TEXT NOT NULL CHECK(ticket_type IN ('BODY','MOUNG')),
 stake_kyat INTEGER NOT NULL CHECK(stake_kyat>0),
 status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','SETTLED','LOST','REFUNDED')),
 payout_kyat INTEGER CHECK(payout_kyat>=0),net_kyat INTEGER,
 idempotency_key TEXT NOT NULL,
 accepted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 settled_at TEXT,
 UNIQUE(organization_id,ticket_number),UNIQUE(organization_id,agent_id,idempotency_key),
 UNIQUE(id,organization_id),
 FOREIGN KEY(agent_id,organization_id) REFERENCES users(id,organization_id),
 CHECK((payout_kyat IS NULL AND net_kyat IS NULL) OR net_kyat=payout_kyat-stake_kyat)
);
CREATE INDEX IF NOT EXISTS tickets_org_agent ON tickets(organization_id,agent_id,accepted_at DESC);
CREATE TABLE IF NOT EXISTS ticket_selections (
 id TEXT PRIMARY KEY,organization_id TEXT NOT NULL,ticket_id TEXT NOT NULL,
 match_id TEXT NOT NULL,quote_id TEXT NOT NULL,position INTEGER NOT NULL CHECK(position BETWEEN 1 AND 12),
 chosen_side TEXT NOT NULL CHECK(chosen_side IN ('HOME','AWAY','OVER','UNDER')),
 quote_snapshot TEXT NOT NULL,
 settlement_state TEXT NOT NULL DEFAULT 'PENDING' CHECK(settlement_state IN ('PENDING','SETTLED','VOID')),
 factor_bp INTEGER CHECK(factor_bp BETWEEN 0 AND 20000),
 UNIQUE(ticket_id,position),UNIQUE(ticket_id,match_id),
 FOREIGN KEY(ticket_id,organization_id) REFERENCES tickets(id,organization_id),
 FOREIGN KEY(match_id,organization_id) REFERENCES matches(id,organization_id),
 FOREIGN KEY(quote_id,organization_id) REFERENCES odds_quotes(id,organization_id)
);
CREATE INDEX IF NOT EXISTS selection_match ON ticket_selections(organization_id,match_id);
CREATE TABLE IF NOT EXISTS ledger_entries (
 id TEXT PRIMARY KEY,organization_id TEXT NOT NULL REFERENCES organizations(id),
 agent_id TEXT NOT NULL,ticket_id TEXT NOT NULL,
 player_net_delta_kyat INTEGER NOT NULL,
 event_type TEXT NOT NULL CHECK(event_type IN ('SETTLEMENT','REVERSAL')),
 note TEXT,created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 UNIQUE(ticket_id,event_type),
 FOREIGN KEY(agent_id,organization_id) REFERENCES users(id,organization_id),
 FOREIGN KEY(ticket_id,organization_id) REFERENCES tickets(id,organization_id)
);
CREATE INDEX IF NOT EXISTS ledger_org_agent ON ledger_entries(organization_id,agent_id);
CREATE TABLE IF NOT EXISTS audit_logs (
 id TEXT PRIMARY KEY,organization_id TEXT REFERENCES organizations(id),
 actor_id TEXT REFERENCES users(id),action TEXT NOT NULL,entity TEXT NOT NULL,entity_id TEXT,
 details TEXT,created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS audit_org ON audit_logs(organization_id,created_at DESC);
-- Concurrency protection: a second confirmation cannot alter a settled match.
CREATE TRIGGER IF NOT EXISTS match_final_immutable BEFORE UPDATE OF status ON matches
WHEN OLD.status != 'SCHEDULED'
BEGIN SELECT RAISE(ABORT,'Settled match status immutable'); END;
