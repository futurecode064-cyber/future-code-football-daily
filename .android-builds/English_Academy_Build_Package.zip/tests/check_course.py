import json, pathlib, re
r=pathlib.Path(__file__).resolve().parents[1]
d=json.loads((r/'android/assets/lessons.json').read_text())
assert len(d['lessons'])==48
assert list(d['levels'])==['A0','A1','A2','B1','B2','C1']
assert len(set(x['id'] for x in d['lessons']))==48
for x in d['lessons']:
 assert all(x[k] for k in ('title','goal','target','translation','grammar','reading','writing'))
 assert len(x['phrases'])==4
 assert x['phrases'][0]==x['target']
 assert len(x['translation'])>=10
js=(r/'android/assets/app.js').read_text()
assert 'SpeechRecognition' in js and 'localStorage' in js and 'checkUpdate' in js
print('PASS: 48 original lessons, 6 CEFR-style levels, bilingual text, speech/write/quiz and progress hooks')
