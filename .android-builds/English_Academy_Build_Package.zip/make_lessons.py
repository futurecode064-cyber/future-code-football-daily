import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
# Every record is original bilingual instructional material: title, goal, target utterance, Myanmar translation, grammar focus, 3 additional useful expressions
DATA={
'A0':[
('English Alphabet','A မှ Z အက္ခရာနှင့် အသံကို စတင်လေ့လာမယ်','A is for apple.','A က ပန်းသီးကို ကိုယ်စားပြုပါတယ်။','“is for” ဆိုတာ ကိုယ်စားပြုသော စကားလုံးကို ချိတ်ဆက်ပေးသည်။','B is for book.|C is for cat.|Please say the alphabet.'),
('Hello & Goodbye','နှုတ်ဆက်ခြင်းနဲ့ ပြန်လည်ဖြေကြားခြင်း','Hello! Nice to meet you.','မင်္ဂလာပါ။ တွေ့ရတာ ဝမ်းသာပါတယ်။','Nice to meet you ဟာ ပထမဆုံးတွေ့ဆုံစဉ် သုံးသည်။','Good morning.|How are you?|See you tomorrow.'),
('My Name','နာမည်မိတ်ဆက်နည်း','My name is Aye Aye.','ကျွန်မနာမည် အေးအေးပါ။','My name is + နာမည်။','What is your name?|I am from Myanmar.|You can call me Aye.'),
('Yes and No','အလွယ်ဆုံး မေးခွန်းနဲ့ အဖြေ','Yes, I am a student.','ဟုတ်ပါတယ်၊ ကျွန်တော်/ကျွန်မ ကျောင်းသား/သူပါ။','Are you ...? ကို Yes, I am / No, I am not ဖြေပါ။','Are you ready?|No, I am not tired.|Yes, of course.'),
('Numbers','ဂဏန်းရေတွက်ခြင်း','I have three books.','ကျွန်တော်/ကျွန်မမှာ စာအုပ်သုံးအုပ်ရှိတယ်။','one, two, three တို့ကို countable nouns ရှေ့မှာ သုံးသည်။','One, two, three.|How many?|I have ten pencils.'),
('Days of the Week','ရက်သတ္တပတ် ခုနစ်ရက်','Today is Monday.','ဒီနေ့ တနင်္လာနေ့ပါ။','Today is + day. ရက်နာမည်ကို အကြီးစာလုံးဖြင့် စရေးပါ။','Tomorrow is Tuesday.|What day is it?|See you on Friday.'),
('Colors','အရောင်အမည်များ','The bag is blue.','အိတ်က အပြာရောင်ပါ။','The + noun + is + color.','I like green.|This is a red pen.|What color is it?'),
('Family','မိသားစုအကြောင်း','This is my mother.','ဒါက ကျွန်တော်/ကျွန်မရဲ့ မိခင်ပါ။','my, your, his, her တို့ဟာ ပိုင်ဆိုင်မှု ပြစကားလုံးများ။','I have one brother.|She is my sister.|We are a family.')],
'A1':[
('Daily Routine','နေ့စဉ် လုပ်ဆောင်ချက် ပြောမယ်','I wake up at six o’clock.','ကျွန်တော်/ကျွန်မ မနက်ခြောက်နာရီမှာ အိပ်ရာထတယ်။','Habit ကို Present Simple tense ဖြင့် ပြောပါ။','I brush my teeth.|I go to work.|I sleep at ten.'),
('Question Words','What, Where, When နဲ့ မေးမယ်','Where do you live?','သင် ဘယ်မှာ နေထိုင်ပါသလဲ။','Where + do/does + subject + verb?','What do you do?|When do you study?|Why are you late?'),
('Ordering Food','စားသောက်ဆိုင်မှာ မှာယူခြင်း','I would like chicken rice, please.','ကြက်သားထမင်း တစ်ပွဲ လိုချင်ပါတယ်။','I would like ... ဟာ ယဉ်ကျေးစွာ အမိန့်မှာသည့် ပုံစံ။','May I see the menu?|No spicy food, please.|Can I have the bill?'),
('Asking Directions','လမ်းညွှန် မေးမြန်းခြင်း','How can I get to the hospital?','ဆေးရုံကို ဘယ်လိုသွားရမလဲ။','How can I get to + နေရာ?','Turn left.|Go straight ahead.|Is it far from here?'),
('Shopping','ဈေးဝယ်ရာမှာ စကားပြောခြင်း','How much does this shirt cost?','ဒီအင်္ကျီ ဘယ်လောက်ကျသလဲ။','How much does this + item + cost?','Do you have a smaller size?|Can I try it on?|That is too expensive.'),
('Telling Time','နာရီနှင့် အချိန်အကြောင်း','The meeting starts at nine.','အစည်းအဝေးက ကိုးနာရီမှာ စတင်ပါတယ်။','at ကို တိကျတဲ့အချိန်ရှေ့မှာ သုံးပါ။','It is half past eight.|What time is it?|I will be there at noon.'),
('My Home','အိမ်အကြောင်း ဖော်ပြခြင်း','There is a table in the kitchen.','မီးဖိုချောင်ထဲမှာ စားပွဲတစ်လုံးရှိပါတယ်။','There is + တစ်ခု / There are + အများ။','My room is small.|There are two windows.|The bathroom is upstairs.'),
('Work and Jobs','အလုပ်အကိုင်နဲ့ ကိုယ့်ကိုယ်ကို မိတ်ဆက်ခြင်း','I work as a designer.','ကျွန်တော်/ကျွန်မ ဒီဇိုင်နာတစ်ယောက်အဖြစ် အလုပ်လုပ်ပါတယ်။','I work as + profession.','She works in a school.|I am looking for a job.|What is your occupation?')],
'A2':[
('Travel Check-in','ခရီးသွားနှင့် ဟိုတယ်မှာ ပြောဆိုခြင်း','I have a reservation under my name.','ကျွန်တော်/ကျွန်မ နာမည်နဲ့ ကြိုတင်ဘွတ်ကင်ရှိပါတယ်။','I have + noun ဟာ ပိုင်ဆိုင်မှု၊ အခြေအနေပြခြင်း။','Could I check in now?|Is breakfast included?|I need a single room.'),
('Yesterday & Past Simple','အတိတ်က ဖြစ်ရပ် ပြောပြခြင်း','I visited my friend yesterday.','မနေ့က သူငယ်ချင်းဆီ သွားလည်ခဲ့တယ်။','Past Simple မှာ regular verbs အများအားဖြင့် -ed ပေါင်းသည်။','We watched a film.|Did you go to school?|I did not eat breakfast.'),
('Future Plans','အနာဂတ်အစီအစဉ် ပြောဆိုခြင်း','I am going to study tonight.','ဒီည စာလေ့လာဖို့ စီစဉ်ထားပါတယ်။','be going to + verb သည် စီစဉ်ထားသော အနာဂတ်။','We will meet tomorrow.|Are you free this weekend?|I plan to travel.'),
('At the Clinic','ကျန်းမာရေးအကြောင်း နေရာနှင့်စကား','I have had a headache since morning.','မနက်ကတည်းက ခေါင်းကိုက်နေပါတယ်။','since = စတင်ချိန်၊ for = ကြာချိန်။','Where does it hurt?|I need to see a doctor.|I feel better today.'),
('Weather Talk','ရာသီဥတု ဖော်ပြခြင်း','It looks like it will rain.','မိုးရွာတော့မယ့်ပုံပါ။','It looks like ... သည် ခန့်မှန်းပြောဆိုခြင်း။','It is cloudy.|The weather is getting warmer.|Bring an umbrella.'),
('Comparisons','နှိုင်းယှဉ်သုံးစွဲခြင်း','This road is wider than that one.','ဒီလမ်းက ဟိုလမ်းထက် ပိုကျယ်ပါတယ်။','adjective + er + than / more + adjective + than.','Tea is cheaper than coffee.|This is the best choice.|He is taller than me.'),
('Invitations','ဖိတ်ကြားခြင်းနှင့် ပြန်လည်ဖြေကြားခြင်း','Would you like to join us for dinner?','ညစာအတူစားဖို့ လာချင်ပါသလား။','Would you like to + verb? ယဉ်ကျေးသော ဖိတ်ကြားချက်။','Thanks for inviting me.|I would love to.|Sorry, I have other plans.'),
('Phone Calls','ဖုန်းခေါ်ဆိုမှုအခြေခံ','Could I speak to the manager, please?','မန်နေဂျာနဲ့ စကားပြောခွင့်ရမလား။','Could I ...? ဟာ polite request ပုံစံ။','Who is calling, please?|Please hold the line.|Can I call you back?')],
'B1':[
('Life Experiences','အတွေ့အကြုံ ဖော်ပြခြင်း','I have never traveled abroad.','နိုင်ငံခြားကို တစ်ခါမှ မသွားဖူးပါ။','Present Perfect: have/has + past participle.','Have you ever tried sushi?|I have worked here for years.|I have already finished.'),
('Giving Opinions','အမြင်၊ သဘောထားကို ပြောဆိုခြင်း','In my opinion, practice matters most.','ကျွန်တော်/ကျွန်မ အမြင်အရ လေ့ကျင့်မှုက အရေးအကြီးဆုံးပါ။','In my opinion ... ဖြင့် ကိုယ်ပိုင်အမြင် စတင်နိုင်သည်။','I see your point.|I partly agree.|From my perspective, it helps.'),
('Solving Problems','ပြဿနာရှင်းနိုင်စွမ်း','We should identify the root cause first.','အရင်ဆုံး အဓိက အကြောင်းရင်းကို သတ်မှတ်သင့်တယ်။','should + verb သည် အကြံပြုချက်။','What are our options?|Let us test another approach.|We need a practical solution.'),
('Tell a Story','အဖြစ်အပျက် စီစဉ်ပြောဆိုခြင်း','While I was walking, it started raining.','လမ်းလျှောက်နေစဉ် မိုးစရွာခဲ့တယ်။','Past Continuous + while; Past Simple + when.','At first, everything was fine.|Suddenly, the lights went out.|In the end, we succeeded.'),
('Workplace English','ရုံးမှာ နေ့စဉ်သုံး စကားများ','I will send you the revised document.','ပြင်ဆင်ထားတဲ့ စာရွက်စာတမ်းကို ပို့ပေးမယ်။','will + base verb က အနာဂတ်လုပ်ဆောင်ချက်ကို ပြောသည်။','Could you clarify the deadline?|I have completed the task.|Let us follow up tomorrow.'),
('Running Meetings','အစည်းအဝေးတွင် ပြောဆိုခြင်း','Let us move to the next agenda item.','နောက်ထပ် အစီအစဉ်အကြောင်းအရာကို ဆက်ကြရအောင်။','Let us + verb သည် အတူလုပ်ရန် အဆိုပြုခြင်း။','Shall we get started?|Any questions so far?|Could you summarize the decision?'),
('Email Writing','အီးမေးလ် ရေးသားပုံ','I am writing to request more information.','အချက်အလက် ထပ်မံတောင်းခံရန် ရေးသားလိုက်ပါတယ်။','Formal email တွင် အကြောင်းရင်းကို စာအစမှာ ဖော်ပြပါ။','Thank you for your email.|Please find the file attached.|I look forward to hearing from you.'),
('Culture & Etiquette','ယဉ်ကျေးမှု ကွာခြားချက် ဆွေးနွေးခြင်း','It is important to respect local customs.','ဒေသအလေ့အထများကို လေးစားဖို့ အရေးကြီးပါတယ်။','It is important to + verb လိုအပ်ချက်ကို ဖော်ပြသည်။','Different cultures value different things.|Let us be respectful.|Please explain this tradition.')],
'B2':[
('Negotiation Skills','ညှိနှိုင်းဆွေးနွေးခြင်း','We may be able to reach a compromise.','နှစ်ဖက်သဘောတူညီမှုတစ်ခု ရနိုင်ပါတယ်။','may be able to + verb သည် ဖြစ်နိုင်စွမ်းကို သတိထားဖော်ပြခြင်း။','What terms would work for you?|We need some flexibility.|Could we revisit the price?'),
('Structured Debate','အငြင်းအခုံ ယုတ္တိတန်အောင် တင်ပြခြင်း','The evidence supports a different conclusion.','အထောက်အထားတွေက မတူညီတဲ့ နိဂုံးကို ထောက်ခံထားပါတယ်။','claim → evidence → counterargument → conclusion.','I would challenge that assumption.|That raises an important issue.|There are two sides to this argument.'),
('Complex Sentences','စကားဆက်တွေကို ကျွမ်းကျင်စွာ သုံးခြင်း','Although it was difficult, we succeeded.','ခက်ခဲပေမယ့် ကျွန်တော်တို့ အောင်မြင်ခဲ့တယ်။','Although ... , ... သည် ဆန့်ကျင်မှုဖော်ပြသည့် clause.','Despite the delay, we continued.|However, the results improved.|As a result, sales increased.'),
('Business Proposals','လုပ်ငန်းအစီရင်ခံစာ စတင်တင်ပြခြင်း','Our proposal aims to reduce operating costs.','ကျွန်တော်တို့ အဆိုပြုချက်က လုပ်ငန်းကုန်ကျစရိတ်လျှော့ချဖို့ ရည်ရွယ်ပါတယ်။','aims to + verb; by + gerund သည် လုပ်ဆောင်နည်း။','The budget is realistic.|We anticipate steady growth.|The plan has three phases.'),
('Public Speaking','လူရှေ့ပြောဆိုခြင်း','Today I will outline three key ideas.','ဒီနေ့ အဓိကအချက် သုံးချက်ကို အကျဉ်းချုပ်တင်ပြပါမယ်။','Signposting: first, next, finally.','Let me begin with a question.|This brings me to my next point.|Thank you for your attention.'),
('Phrasal Verbs','ခက်ခဲသော verb combinations','We need to carry out the plan carefully.','အစီအစဉ်ကို သတိထား အကောင်အထည်ဖော်ရမယ်။','carry out = implement; look into = investigate.','Please look into the issue.|Do not put off the meeting.|We ran out of time.'),
('Discussing the News','သတင်းအကြောင်း ချဉ်းကပ်ဆွေးနွေးခြင်း','We should verify the source before sharing.','မျှဝေမယ့်အရင် သတင်းရင်းမြစ်ကို စစ်ဆေးသင့်တယ်။','Evidence versus speculation ကို ခွဲပြောပါ။','The report claims that costs rose.|The figures require context.|That is not yet confirmed.'),
('Research Findings','လေ့လာတွေ့ရှိချက် တင်ပြခြင်း','The results suggest a meaningful improvement.','ရလဒ်တွေက သိသာသော တိုးတက်မှု ရှိနိုင်ကြောင်း ညွှန်ပြပါတယ်။','suggest သည် prove ထက် သတိထားသော ဖော်ပြချက်။','Our sample was limited.|The trend remained consistent.|Further research is required.')],
'C1':[
('Leadership Communication','ခေါင်းဆောင်တစ်ဦးလို ပြောဆိုခြင်း','Our priority is to align the team on outcomes.','ကျွန်တော်တို့ ဦးစားပေးက အသင်းကို ရလဒ်တစ်ခုအပေါ် ညှိနှိုင်းစုစည်းဖို့ပါ။','Complex ideas ကို concise and actionable အဖြစ် တင်ပြပါ။','Let us establish clear expectations.|I value your perspective.|We must remain accountable.'),
('Crisis Management','အရေးပေါ်အခြေအနေ ဆက်သွယ်ပြောဆိုမှု','We are assessing the situation before taking action.','အရေးယူမယ့်အရင် အခြေအနေကို အကဲဖြတ်နေပါတယ်။','Hedging avoids overconfidence: based on current evidence.','We will provide verified updates.|The safety of users comes first.|Our response will be proportionate.'),
('Persuasive Argument','ကျိုးကြောင်းဆီလျော် စည်းရုံးပြောဆိုခြင်း','The long-term benefits outweigh the short-term costs.','ရေရှည်အကျိုးကျေးဇူးက ရေတိုကုန်ကျစရိတ်ထက် ပိုများပါတယ်။','Concession + rebuttal + evidence structure.','Granted, there are limitations.|Nevertheless, the data is compelling.|Consider the wider implications.'),
('Executive Presentations','အဆင့်မြင့် လုပ်ငန်းတင်ပြချက်','The key takeaway is a measurable increase in retention.','အဓိကသိထားရမယ့်အချက်က ဆက်လက်အသုံးပြုမှု သိသာတိုးတက်တာပါ။','One sentence takeaway → metric → implication → action.','Here is the strategic context.|Let me address the central risk.|We recommend a phased rollout.'),
('Academic Writing','တက္ကသိုလ်အဆင့် စာရေးခြင်း','This paper examines the relationship between two factors.','ဒီစာတမ်းမှာ အချက်နှစ်ခုအကြား ဆက်နွယ်မှုကို လေ့လာထားပါတယ်။','Thesis + evidence + citation + limitations.','The literature indicates a gap.|This finding is consistent with prior work.|Further analysis is warranted.'),
('Professional Interviews','အဆင့်မြင့် အလုပ်အင်တာဗျူး','My experience has prepared me to lead cross-functional teams.','ကျွန်တော့်/ကျွန်မအတွေ့အကြုံက ဌာနစုံအသင်းတွေကို ဦးဆောင်နိုင်အောင် ပြင်ဆင်ပေးခဲ့ပါတယ်။','STAR framework: situation, task, action, result.','I delivered measurable results.|My greatest strength is adaptability.|I would welcome that challenge.'),
('Resolving Conflict','အမြင်မတူညီမှုကို ဖြေရှင်းခြင်း','I understand your concern, and I propose an alternative.','သင့်စိုးရိမ်ချက်ကို နားလည်ပါတယ်၊ တခြားနည်းလမ်းတစ်ခု အဆိုပြုပါတယ်။','Acknowledge → clarify → propose → agree.','Let us separate facts from assumptions.|I appreciate your honesty.|We can establish common ground.'),
('Cross-cultural Fluency','အပြည်ပြည်ဆိုင်ရာ ပရော်ဖက်ရှင်နယ် ဆက်ဆံမှု','We should adapt our communication to the audience.','ပရိသတ်နဲ့ လိုက်ဖက်အောင် ဆက်သွယ်ရေးပုံစံကို ပြောင်းသင့်ပါတယ်။','Register and nuance matter: directness varies by context.','This may be interpreted differently.|We should avoid cultural assumptions.|A respectful tone builds trust.')]
}
LEVEL_NAMES={'A0':'Starter • Zero English','A1':'Beginner','A2':'Elementary','B1':'Intermediate','B2':'Upper Intermediate','C1':'Professional'}
lessons=[]
for lvl,items in DATA.items():
 for i,(title,goal,target,mm,grammar,others) in enumerate(items,1):
  expressions=[target]+others.split('|')
  lessons.append({'id':f'{lvl}-{i:02d}','level':lvl,'levelName':LEVEL_NAMES[lvl],'title':title,'goal':goal,'target':target,'translation':mm,'grammar':grammar,'phrases':expressions,'reading':f'{title}. {" ".join(expressions[:3])}','writing':target})
assert len(lessons)==48 and len(set(x['id'] for x in lessons))==48
p=ROOT/'android/assets/lessons.json';p.write_text(json.dumps({'levels':LEVEL_NAMES,'lessons':lessons},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print(len(lessons),'original bilingual lessons',p.stat().st_size,'bytes')
