# Future Code English Academy — v1.0.0 Source & Offline Demo

**Status:** A 48-lesson working offline-first HTML/JS course and native Java Android wrapper with a reproducible Android SDK build script. **An installable APK is NOT included until Android compilation and signing succeed.** Do not rename a ZIP to APK. The web preview is tested separately, not on physical Android.

## Course

6 CEFR-inspired levels: A0 (Starter) → A1 → A2 → B1 → B2 → C1 (Professional). 8 original bilingual lessons per level (48 total). Each lesson includes an English target sentence, Myanmar meaning, grammar guidance, 4 listening sentences, reading drill, writing check, and a choice quiz. Tracks completion, streak and continuation locally. Speech pronunciation practice uses Android's installed Recognizer service and a *heuristic word-overlap score* — not a certified pronunciation grade.

## Android build

1. Install JDK 17, Android command-line SDK, `platforms;android-35`, `build-tools;35.0.0`.
2. Set `ANDROID_HOME` and run `python3 android/build.py`.
3. Build emits `android/build/Future_Code_English_Academy_v1.0.0_unsigned.apk`.
4. Sign with an owner-controlled persistent release keystore, *store the keystore securely*, and verify with `apksigner` before distribution. Increment `versionCode` and sign with **the same key** for every update.
5. Set `site/english-academy/latest.json` `published:true` and correct signed APK path **only after** uploading a verified installable APK.

Sample signing commands (use your own keystore and passphrases, never commit passwords or keystores):

```sh
keytool -genkeypair -v -keystore english-release.jks -alias english -keyalg RSA -keysize 3072 -validity 10000
"$ANDROID_HOME/build-tools/35.0.0/apksigner" sign --ks english-release.jks --ks-key-alias english --out Future_Code_English_Academy_v1.0.0.apk android/build/Future_Code_English_Academy_v1.0.0_unsigned.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose Future_Code_English_Academy_v1.0.0.apk
```

## Website and analytics integration

The static site assets are under `site/english-academy/` and must be copied to the hosting repository's publish directory. They are **not** automatically deployed by this source ZIP. The main landing page currently only displays an APK button when `latest.json` reports `published:true`; it does not pretend a missing APK is downloadable.

Counting **completed downloads** needs Cloudflare Worker/server tracking for the new `/english-academy/*.apk` route plus a database/owner dashboard. A JavaScript button-click counter is not the same as successful APK download or install. This integration must be deployed/verified separately. No install analytics or analytics provider is silently enabled by the app.

## Updates and announcements

`MainActivity` fetches HTTPS `/english-academy/latest.json` on launch and on manual request. When `versionCode` exceeds installed value and the URL is trusted, it prompts to open the website APK download. Android users may need to approve installation; it is not silent background update. `PollJob` checks `/english-academy/notifications.json` periodically while users have opted in; Android battery limits may delay jobs and Android 13+ requires notification permission. Owner edits the JSON with a new `id` to announce; polling is **not Firebase push** and does not guarantee real-time delivery. The current `notifications.json` is inactive.

## Tests

`python tests/check_course.py`, `node --check android/assets/app.js` and use the standalone web demo `android/assets/index.html`. Android SDK compile, emulator, physical-device, and production URL tests remain required before calling this APK production-ready.
